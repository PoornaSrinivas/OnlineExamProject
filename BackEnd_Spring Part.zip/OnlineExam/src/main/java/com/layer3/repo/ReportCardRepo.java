package com.layer3.repo;

import java.util.List;

import com.layer2.entity.*;

public interface ReportCardRepo {

	
	
    public void addReportCard(ReportCard ref);
    public void removeReportCard(int reportId);
    public List<ReportCard> getAllReportCards();
    public List<ReportCard> getReportCards(int userid);
	
}
