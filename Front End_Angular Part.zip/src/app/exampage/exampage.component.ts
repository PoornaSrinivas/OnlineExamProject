import { Component, OnInit } from '@angular/core';
import { AddResponsesForExamDto } from '../AddResponsesForExamDto';
import { ExamInformationDto } from '../ExamInformationDto';
import { OnlineexamService } from '../onlineexam.service';
import { ReportCardDto } from '../ReportCardDto';
import { ResponseInfoDto } from '../ResponseInfoDto';
import { SendObjectService } from '../send-object.service';
import { UserInfoDto } from '../UserInfoDto';

@Component({
  selector: 'app-exampage',
  templateUrl: './exampage.component.html',
  styleUrls: ['./exampage.component.css']
})
export class ExampageComponent implements OnInit {

  constructor(private service: OnlineexamService,
              private sendService: SendObjectService            
  ) { }

  userInfoDto : UserInfoDto = new UserInfoDto();

  examInformationDto : ExamInformationDto = new ExamInformationDto();
  
  addResponsesForExamDto : AddResponsesForExamDto = new AddResponsesForExamDto();

  reportCardDto : ReportCardDto = new ReportCardDto();

  responsesList = [];
   
  rL= [];

  userId : number;

  examSpec : string;

  examLevel : string;
  
  riDto1 : ResponseInfoDto = new ResponseInfoDto();
  riDto2 : ResponseInfoDto = new ResponseInfoDto();
  riDto3 : ResponseInfoDto = new ResponseInfoDto();
  riDto4 : ResponseInfoDto = new ResponseInfoDto();
  riDto5 : ResponseInfoDto = new ResponseInfoDto();
  riDto6 : ResponseInfoDto = new ResponseInfoDto();
  riDto7 : ResponseInfoDto = new ResponseInfoDto();
  riDto8 : ResponseInfoDto = new ResponseInfoDto();
  riDto9 : ResponseInfoDto = new ResponseInfoDto();
  riDto10 : ResponseInfoDto = new ResponseInfoDto();

  reportCardList : any;
  
  questionsList : any;
  //questionsDetailsDto[] : QuestionDetailsDto = new QuestionDetailsDto();

  ngOnInit(): void {
    this.userInfoDto = JSON.parse(sessionStorage.getItem("myUser"));

    if(this.userInfoDto.userId == null){
      console.log("Login first")
      alert('Please login')
      
    }else{
         this.userId=this.userInfoDto.userId;
         this.responsesList.push(this.riDto1);
         this.responsesList.push(this.riDto2);
         this.responsesList.push(this.riDto3);
         this.responsesList.push(this.riDto4);
         this.responsesList.push(this.riDto5);
         this.responsesList.push(this.riDto6);
         this.responsesList.push(this.riDto7);
         this.responsesList.push(this.riDto8);
        this.responsesList.push(this.riDto9);
        this.responsesList.push(this.riDto10);
    }
  } 

  viewQuestionsForExam(){
    console.log(JSON.parse(sessionStorage.getItem("examSpec")))
    console.log(JSON.parse(sessionStorage.getItem("examLevel")))
    
    this.examSpec = JSON.parse(sessionStorage.getItem("examSpec"));
    this.examLevel = JSON.parse(sessionStorage.getItem("examLevel"));
    
    this.examInformationDto.examLevel = this.examLevel;
    this.examInformationDto.examSpecialization = this.examSpec;
    this.service.getQuestionsForExam(this.examInformationDto).subscribe(data => {
      this.questionsList = data;
      console.log(data);
    })
  }

  responseInfoDto : ResponseInfoDto = new ResponseInfoDto();
  addResponsestoList(qId :number, i: number){
    this.responsesList[i].questionId = qId;
    this.responsesList[i].userId = this.userId;
     
  }
  
  submitResponses(){
    console.log(this.examLevel)
    console.log(this.examSpec)
    console.log(this.responsesList)

    this.addResponsesForExamDto.examLevel=this.examLevel;
    this.addResponsesForExamDto.examSpecialization = this.examSpec ;
    this.addResponsesForExamDto.responseList = this.responsesList;
    console.log(this.addResponsesForExamDto);
    this.service.addResponses(this.addResponsesForExamDto).subscribe(data => {

    this.reportCardDto = data;
    console.log(data);
    this.sendReportCardtoReportCardComp();

   })
  }

  sendReportCardtoReportCardComp(){
    this.sendService.communicateObject(this.reportCardDto);

  }
}
