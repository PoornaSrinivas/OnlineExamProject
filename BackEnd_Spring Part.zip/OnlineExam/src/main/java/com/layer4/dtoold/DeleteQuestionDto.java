package com.layer4.dtoold;

public class DeleteQuestionDto {

	private String examSpecialization;
	private String examLevel;
	private int questionId;
	
	
	public String getExamSpecialization() {
		return examSpecialization;
	}
	public void setExamSpecialization(String examSpecialization) {
		this.examSpecialization = examSpecialization;
	}
	public String getExamLevel() {
		return examLevel;
	}
	public void setExamLevel(String examLevel) {
		this.examLevel = examLevel;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	
}
