package com.layer4.dtoold;

public class SearchStudentDto {

	
	private String examSpecialization;
	private String state;
	private String city;
	private String level;
	private int marks;
	
	
	public String getExamSpecialization() {
		return examSpecialization;
	}
	public void setExamSpecialization(String examSpecialization) {
		this.examSpecialization = examSpecialization;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	
	
}
