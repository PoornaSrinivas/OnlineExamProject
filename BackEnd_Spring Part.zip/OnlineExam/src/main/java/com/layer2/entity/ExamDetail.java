package com.layer2.entity;




import java.io.Serializable;
import javax.persistence.*;

import java.util.Set;


/**
 * The persistent class for the EXAM_DETAILS database table.
 * 
 */
@Entity
@Table(name="EXAM_DETAILS")
@NamedQuery(name="ExamDetail.findAll", query="SELECT e FROM ExamDetail e")
public class ExamDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int examid;

	@Column(name="EXAM_LEVEL")
	private String examLevel;

	@Column(name="EXAM_SPECIALIZATION")
	private String examSpecialization;

	@Column(name="NUMBER_OF_QUESTIONS")
	private int numberOfQuestions;

	@Column(name="PASSING_MARK")
	private int passingMark;

	@Column(name="TIME")
	private String time;

	//bi-directional many-to-one association to QuestionsDetail
	@OneToMany(mappedBy="examDetail", cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
	private Set<QuestionsDetail> questionsDetails;

	//bi-directional many-to-one association to ReportCard
	@OneToMany(mappedBy="examDetail", cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
	private Set<ReportCard> reportCards;

	
	

	public ExamDetail() {
		System.out.println("examdetails ctor()..........");
	}

	public int getExamid() {
		return this.examid;
	}

	public void setExamid(int examid) {
		this.examid = examid;
	}

	public String getExamLevel() {
		return this.examLevel;
	}

	public void setExamLevel(String examLevel) {
		this.examLevel = examLevel;
	}

	public String getExamSpecialization() {
		return this.examSpecialization;
	}

	public void setExamSpecialization(String examSpecialization) {
		this.examSpecialization = examSpecialization;
	}

	public int getNumberOfQuestions() {
		return this.numberOfQuestions;
	}

	public void setNumberOfQuestions(int numberOfQuestions) {
		this.numberOfQuestions = numberOfQuestions;
	}

	public int getPassingMark() {
		return this.passingMark;
	}

	public void setPassingMark(int passingMark) {
		this.passingMark = passingMark;
	}

	public String getTime() {
		return this.time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Set<QuestionsDetail> getQuestionsDetails() {
		return this.questionsDetails;
	}

	public void setQuestionsDetails(Set<QuestionsDetail> questionsDetails) {
		this.questionsDetails = questionsDetails;
	}

	/*
	 * public QuestionsDetail addQuestionsDetail(QuestionsDetail questionsDetail) {
	 * getQuestionsDetails().add(questionsDetail);
	 * questionsDetail.setExamDetail(this);
	 * 
	 * return questionsDetail; }
	 * 
	 * public QuestionsDetail removeQuestionsDetail(QuestionsDetail questionsDetail)
	 * { getQuestionsDetails().remove(questionsDetail);
	 * questionsDetail.setExamDetail(null);
	 * 
	 * return questionsDetail; }
	 */

	public Set<ReportCard> getReportCards() {
		return this.reportCards;
	}

	public void setReportCards(Set<ReportCard> reportCards) {
		this.reportCards = reportCards;
	}

	/*
	 * public ReportCard addReportCard(ReportCard reportCard) {
	 * getReportCards().add(reportCard); reportCard.setExamDetail(this);
	 * 
	 * return reportCard; }
	 * 
	 * public ReportCard removeReportCard(ReportCard reportCard) {
	 * getReportCards().remove(reportCard); reportCard.setExamDetail(null);
	 * 
	 * return reportCard; }
	 */

	@Override
	public String toString() {
		return "ExamDetail [examid=" + examid + ", examLevel=" + examLevel + ", examSpecialization="
				+ examSpecialization + ", numberOfQuestions=" + numberOfQuestions + ", passingMark=" + passingMark
				+ ", time=" + time + "]";
	}
}
