package com.layer3.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.layer2.entity.ExamDetail;
import com.layer2.entity.QuestionsDetail;
import com.layer2.entity.StudentRespons;
import com.layer2.entity.UserDetail;

@Repository
public interface UserDetailRepo {

	//UserDetails Operations
	public UserDetail getOneUser(int userId);
	public UserDetail getOneUser(String email);
	public List<UserDetail> getAllUsers();
	public void addUser(UserDetail ref);
	public void updateUserEmail(int userId, String newEmail);
	public void updateUserPassword(int userId, String newPass);
	public void updateUserMobilNumber(int userId, String newMobileNumber);
	public void removeUser(int userId);
	public List<UserDetail> getuser(int userid);//not required
	public List<UserDetail> getuserswithstateandcity(String State ,String city);
	
		
}
