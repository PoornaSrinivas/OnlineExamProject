package com.layer3.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.layer2.entity.*;

@Repository
public class StudentResponsRepoImpl implements StudentResponsRepo {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
    public void addstudentresponses(StudentRespons resp) { //3. to add new student responses
        
        System.out.println(entityManager);
        //entityManager.persist(resp);
        entityManager.merge(resp);
    }
	
	@Transactional
    public void removeStudentresponse(int responseid) {	//4.to remove student responses
        Query query=entityManager.createQuery("delete from StudentRespons where responseid="+responseid);
        int rowsDeleted=query.executeUpdate();
        System.out.println("------------------------------------------");
        System.out.println("removed using entity manager");
        System.out.println("------------------------------------------");
    }
	
	
	 @Transactional //1. to get only one user response	
 	 public List<StudentRespons> getResponses(int userId) {
		 Query query =  entityManager.createQuery("FROM  StudentRespons WHERE userid="+userId); 
		 System.out.println("Query generated...");
		 List<StudentRespons> stdlist = query.getResultList();
		 System.out.println("List has generated...");
		 
		 return stdlist;
	 }

	@Transactional
	public List<StudentRespons> getallresponses() {	//2. to get all the responses
		Query query = entityManager.createQuery(" from StudentRespons");
		List<StudentRespons> sr = query.getResultList();
		return sr;
	}


	@Override
	public StudentRespons getsingleresponse(int userid, int questionid) {
		Query query = entityManager.createQuery(" FROM  StudentRespons WHERE userid = "+userid+" and questionid = "+questionid);
		List<StudentRespons> srList = query.getResultList();
		return srList.get(0);
	}


}


