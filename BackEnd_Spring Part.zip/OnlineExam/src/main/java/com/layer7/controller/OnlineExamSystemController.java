package com.layer7.controller;

import java.time.LocalDate;
import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.layer3.repo.UserDetailRepo;
import com.layer4.dto.*;

import com.layer5.exception.OnlineExamException;
import com.layer6.service.*;

@RestController
@CrossOrigin
public class OnlineExamSystemController {
	
	@Autowired
	LoginService lSer;
	
	@Autowired
	ExamService eSer;
	
	@Autowired
	ReportCardService rcSer;
	
	@Autowired
	UserDetailRepo udRepo;
	
	
	@RequestMapping("/")
	@ResponseBody
	public String home() {
		return "<h1>Welcom to Online Exam System </h1>";
		
	}
	@RequestMapping("/home")
	@ResponseBody
	public String home2() {
		return "<h2>Welcom to Online Exam System homepaeg2 </h2>";
		
	}
	
	/*
	 * @PostMapping(path="/login")//to login public String userLogin(@RequestBody
	 * UserLoginDto ulDto) {
	 * 
	 * try {
	 * 
	 * lSer.userLogin(ulDto); String status = "User Logged In successfully";
	 * 
	 * System.out.println("------------------------------");
	 * System.out.println("Status is :" +status);
	 * System.out.println("------------------------------"); return status;
	 * 
	 * } catch (OnlineExamException e) {
	 * 
	 * String status = e.getMessage();
	 * System.out.println("------------------------------");
	 * System.out.println("Status is :" +status);
	 * System.out.println("------------------------------"); return status; } }
	 */
	
	@PostMapping(path="/userlogin")//to login
	public UserInfoDto userLoginService(@RequestBody UserLoginDto ulDto) {
		//Status status = new Status();
		
			
			UserInfoDto userInfoDto = new UserInfoDto();
			try {
				userInfoDto = lSer.userLoginService(ulDto);
				
			} catch (OnlineExamException e) {
				System.out.println("Error : "+e.getMessage());
			}
			return userInfoDto;
			//status.setMessage("User Logged In successfully");
			//status.setStatus(StatusType.SUCCESS);
			
			//return status;
			
	
			
			//status.setMessage(e.getMessage());
			//status.setStatus(StatusType.FAILURE);
	}	
	
	@PostMapping(path="/adminlogin")//to login
	public AdminLoginDto adminLoginService(@RequestBody AdminLoginDto alDto) {
		//Status status = new Status();
		
			
		AdminLoginDto adminLoginDto = new AdminLoginDto();
			try {
				adminLoginDto = lSer.adminLoginService(alDto);
				
			} catch (OnlineExamException e) {
				System.out.println("Error : "+e.getMessage());
			}
			return adminLoginDto;
			//status.setMessage("User Logged In successfully");
			//status.setStatus(StatusType.SUCCESS);
			
			//return status;
			
	
			
			//status.setMessage(e.getMessage());
			//status.setStatus(StatusType.FAILURE);
	}	
	
	
	
	@PostMapping(path="/addquestionsforexam")//to add questions for a particular exam
	public String addQuestionsForExamService(@RequestBody AddQuestionsForExamDto aqeDto) {
		
		try {
			eSer.addQuestionsForExamService(aqeDto);
			System.out.println("Added successfully");
			return "Y";
			
		}catch (OnlineExamException e) {
			
			return e.getMessage();		
		}
		
	}
	
	@PostMapping(path="/getquestionsforexam")//to display all questions of a selected exam
	public Set<QuestionDetailsDto> getAllquestionsForExamService(@RequestBody ExamInformationDto examInfoDto){
		Set<QuestionDetailsDto> qList = eSer.getAllquestionsForExamService(examInfoDto);
		return qList;
		
	}
	
	@PutMapping(path="/resetpassword")//to reset password
	public Message resetPasswordService(@RequestBody ResetPasswordDto rpDto) {
		
		Message message = new Message();
		try {
			String msg = lSer.resetPasswordService(rpDto);
			message.setStatus("Y");
			message.setMsg(msg);
			return message;
		} catch (OnlineExamException e) {
			message.setStatus("N");
			message.setMsg(e.getMessage());
			return message;
		}
		
		
	}
	
	@GetMapping(path="/getallexams")//to display the information of all exams
	public Set<ExamInformationDto> selectExamsService(){
		
		Set<ExamInformationDto> allExams = eSer.selectExamsService();
		return allExams;
		
	}
	
	
	@PostMapping(path="/deletequestionsforexam")//to delete questions of a particualr exam
	public String deleteQuestionsForExamService(@RequestBody DeleteQuestionsForExamDto dqeDto) {
		
		String status;
		try {
			status = eSer.deleteQuestionsForExamService(dqeDto);
			return status;
		} catch (OnlineExamException e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
		
		
	}
	
	
	@GetMapping(path="/getreportcard/{userid}")//to get list of reportcards for a user.
	public  Set<ReportCardDto> getReportCardService(@PathVariable(value = "userid") int userId){
		
		Set<ReportCardDto> reportCardsDtoSet = rcSer.getReportCardService(userId);
		
		return reportCardsDtoSet;
	}
		
		
	@PostMapping(path="/searchstudentsinfo")	//gives the info of students, where there some searching criteria like(city,state,exam,marks)
	public Set<UserInfoDto> searchStudentService(@RequestBody SearchStudentDto ssDto){
		
		Set<UserInfoDto> userInfoDtoList = rcSer.searchStudentService(ssDto);
		return userInfoDtoList;
	}
	
	@PostMapping(path="/addresponses")//to add responses after completing the exam. It will also generate the reportcard for that particular exam
	public ReportCardDto addResponsesService(@RequestBody AddResponsesForExamDto areDto) {
		
		ReportCardDto reportCard = eSer.addResponsesService(areDto);
		return reportCard;
			
	}
	
	@PostMapping(path="/registeruser")//to register a new user
	public Message userRegisterService(@RequestBody UserRegisterDto rgDto) {
		Message message = new Message();
		try {
			String status = lSer.userRegisterService(rgDto);
			message.setStatus("Y");
			message.setMsg(status);
		} catch (OnlineExamException e) {
			message.setStatus("N");
			message.setMsg("Unable to register");
		} 
		
		return message;
	}
	
	@GetMapping(path="/date")
	public  Date getDate(){
		return udRepo.getOneUser(1).getDateOfBirth();
	}
		
}
