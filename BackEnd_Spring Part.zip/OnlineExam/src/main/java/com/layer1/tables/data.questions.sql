

63 php level1
64 php level2
65 php level3

INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	116,
	'What does PHP stand for?',
	'Personal Home Page',
	'Hypertext Preprocessor',
	'Pretext Hypertext Processor',
	'Both a) and b)',
	'D',
	63);


INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	117,
	'PHP files have a default file extension of_______',
	'.html',
	'.xml',
	'.php',
	'.ph',
	'C',
	63);


INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	118,
	'How many error levels are available in PHP?',
	'14',
	'15',
	'16',
	'17',
	'C',
	63);


INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	119,
	'Notepad',
	'Notepad++',
	'Adobe Dreamweaver',
	'All of these',
	'D',
	63);

INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	120,
	'Which one of the following function is used to start a session?',
	'start_session()',
	'session_start()',
	'session_begin()',
	'begin_session()',
	'B',
	63);

INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) 
VALUES(	121,
	'What does PHP stand for?',
	'Personal Home Page',
	'Hypertext Preprocessor',
	'Pretext Hypertext Processor',
	'Both a) and b)',
	'A',
	63);



























service:
-------

@Override
	public UserInfoDto userLogin(UserLoginDto ulDto){
		
		
			UserInfoDto userInfoDto = new UserInfoDto();
			String email = ulDto.getUserEmail();
			String password = ulDto.getPassword();
			
			UserDetail udRef = udRepo.getOneUser(email); 
			System.out.println("====================================");
			System.out.println("got the udRef :"+udRef.getPassword()+"  userid "+udRef.getUserid());
			System.out.println("====================================");
			
			System.out.println("====================================");
			System.out.println("ulDto :"+ulDto.getPassword());
			System.out.println("====================================");
			
			if(password.equals(udRef.getPassword())) {
				userInfoDto.setUserId(udRef.getUserid());
				userInfoDto.setEmail(udRef.getEmail());
				System.out.println("PasswordMatched");
				
			}
		return userInfoDto;		
	}



angular
-----------

checkLogin(){
    this.service.getUser(this.userLoginDto).subscribe(data => {
      this.userInfoDto = data;
    if(data == null){
      alert("Invalid Email")}
    else{
       console.log(this.userInfoDto);
      console.log(JSON.stringify(this.userInfoDto.email)); 
       sessionStorage.setItem("myUser", JSON.stringify(data));    
      
       if(this.userInfoDto.email!==null){
         alert("Loggedin successfully")
         this.router.navigate(['/welcome']);
          this.sendNameToWelcomPage();
        }else{
        alert("Invalid credentials")
     }
    }
    })
    error =>{
      console.log("exception occured");
      this.msg="not login"    }  
    
    }
    sendNameToWelcomPage(){
      this.sendService.communicateUserInfoDto(this.userInfoDto);
    
  }








