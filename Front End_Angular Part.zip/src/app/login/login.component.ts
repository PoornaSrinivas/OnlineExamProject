import { Component, OnInit } from '@angular/core';
import { OnlineexamService } from '../onlineexam.service';
import { UserInfoDto } from '../UserInfoDto';
import { UserLoginDto } from '../UserLoginDto';
import { Router } from '@angular/router';
import { SendObjectService } from '../send-object.service';
import { AdminLoginDto } from '../AdminLoginDto';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userLoginDto : UserLoginDto = new UserLoginDto();
  userInfoDto : UserInfoDto = new UserInfoDto();
  adminLoginDto : AdminLoginDto = new AdminLoginDto();
  sessionAdmin : AdminLoginDto = new AdminLoginDto();
  msg = " ";
  constructor(private service: OnlineexamService,
              private router: Router,
              private sendService: SendObjectService          
  ) { }

  ngOnInit(): void {
  }

  checkLogin(){
    this.service.getUser(this.userLoginDto).subscribe(data => {
    this.userInfoDto = data;
    if(this.userInfoDto.status == "N"){
      alert("Invalid Login Details")}

    else{
      console.log(this.userInfoDto);
      console.log(JSON.stringify(this.userInfoDto.email)); 
      sessionStorage.setItem("myUser", JSON.stringify(data));    
      
       if(this.userInfoDto.email!==null){
         alert("Loggedin successfully")
         this.router.navigate(['/welcome']);
         // this.sendNameToWelcomPage();
        }else{
        alert("Invalid credentials")
     }
    }
    }) 
    
    }
  //sendNameToWelcomPage(){
 //     this.sendService.communicateUserInfoDto(this.userInfoDto);
    
 // }

  checkAdminLogin(){
    this.service.getAdmin(this.adminLoginDto).subscribe(data => {
    this.sessionAdmin = data;
    if(this.sessionAdmin.status == "N"){
      alert("Invalid Login Details")}
    else{
       console.log(this.sessionAdmin);
      console.log(JSON.stringify(this.sessionAdmin.adminEmail)); 
       sessionStorage.setItem("myAdmin", JSON.stringify(data));    
      
       if(this.userInfoDto.email!==null){
         alert("Loggedin successfully")
         this.router.navigate(['/adminwelcome']);
          //this.sendNameToWelcomPage();
        }else{
        alert("Invalid credentials")
     }
    }
    })
    
    }
}
