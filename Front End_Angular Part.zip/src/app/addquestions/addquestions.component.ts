import { Component, OnInit } from '@angular/core';
import { AddQuestionDto } from '../AddQuestionDto';
import { AddquestionsForExamDto } from '../AddQuestionsForExamDto';
import { ExamInformationDto } from '../ExamInformationDto';
import { OnlineexamService } from '../onlineexam.service';

@Component({
  selector: 'app-addquestions',
  templateUrl: './addquestions.component.html',
  styleUrls: ['./addquestions.component.css']
})
export class AddquestionsComponent implements OnInit {

  examInformationDto : ExamInformationDto = new ExamInformationDto();

  noOfQuestions : number;

  status : string;

  addQuestionDto1 : AddQuestionDto = new AddQuestionDto();
  

  questionsList = [];

  addQuestionsForExamDto : AddquestionsForExamDto = new AddquestionsForExamDto();

  id=[]
  ids=[]

  constructor(private service: OnlineexamService) { }

  ngOnInit(): void {
    // let j=0;
    //  for(let i=1;i<50;){

    //    for(let j=i; j<i+4; j++){
    //      this.id.push(j)
    //    }
    //    i=j;
    //    this.ids.push(this.id)
    //  } 
    //  console.log(this.ids);
      
  }

createSlots(){
  for(let i=0; i<this.noOfQuestions; i++){
    this.questionsList.push(this.addQuestionDto1);
  }
}
addQuestions(){
  console.log(this.addQuestionsForExamDto)
  this.service.addQuestionsForExam(this.addQuestionsForExamDto).subscribe((data)=>{
    this.status=JSON.parse("data");
    if(data!=null){
      alert("Questions are adde successfully")
    
       
       console.log(this.status)
    }
  },(err)=>{
    alert("Failed to add questions")
    console.log(err)
  })

}
addQuestionsToExam(){
 this.addQuestionsForExamDto.questionsList = this.questionsList;
 this.addQuestionsForExamDto.examLevel = this.examInformationDto.examLevel;
 this.addQuestionsForExamDto.examSpecialization=this.examInformationDto.examSpecialization;
 console.log(this.addQuestionsForExamDto)
 this.addQuestions();
}
}
