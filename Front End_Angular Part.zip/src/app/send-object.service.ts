import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ReportCardDto } from './ReportCardDto';
import { UserInfoDto } from './UserInfoDto';

@Injectable({
  providedIn: 'root'
})
export class SendObjectService {

  sendUserInfoDto = new Subject<UserInfoDto>();
  sendObject = new Subject<ReportCardDto>();
  constructor() { }

  communicateObject(obj){
    this.sendObject.next(obj);
  }
  communicateUserInfoDto(obj){
    this.sendUserInfoDto.next(obj);
  }
}
