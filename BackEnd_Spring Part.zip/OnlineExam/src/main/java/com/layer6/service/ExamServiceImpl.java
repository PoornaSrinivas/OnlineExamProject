package com.layer6.service;

import java.util.ArrayList;
import java.util.HashSet;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.deser.AbstractDeserializer;
import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dto.*;
import com.layer5.exception.OnlineExamException;


@Service
public class ExamServiceImpl implements ExamService {

	@Autowired
	UserDetailRepo udRepo;
	
	@Autowired
	QuestionsDetailRepo qdRepo;
	
	@Autowired
	ExamDetailRepo edRepo;
	
	@Autowired
	StudentResponsRepo srRepo;

	@Autowired
	ReportCardService rcSer;

	@Override
	public String addQuestionsForExamService(AddQuestionsForExamDto aqeDto) throws OnlineExamException {
		
		
		ExamDetail exam = edRepo.getOneExam(aqeDto.getExamSpecialization(),	aqeDto.getExamLevel());//Fetching exam based on specializationa and level
		
		for( AddQuestionDto addQuestionDto : aqeDto.getQuestionsList()) {
			
			try {
				QuestionsDetail questionDetail = new QuestionsDetail();
				questionDetail.setQuestion(addQuestionDto.getQuestion());
				questionDetail.setOptiona(addQuestionDto.getOptionA());
				questionDetail.setOptionb(addQuestionDto.getOptionB());
				questionDetail.setOptionc(addQuestionDto.getOptionC());
				questionDetail.setOptiond(addQuestionDto.getOptionD());
				questionDetail.setAnswer(addQuestionDto.getAnswer());
				questionDetail.setExamDetail(exam);
				qdRepo.addQuestion(questionDetail);
				
				System.out.println("------------------------------------------");
				System.out.println("Questions added");
				System.out.println("------------------------------------------");
				
			} catch (Exception e) {
				System.out.println("Error: Unable to add the Questions");
				throw new OnlineExamException("N");
			}	
			
		}
		return "Y";
	}


	@Override
	public Set<QuestionDetailsDto> getAllquestionsForExamService(ExamInformationDto examInfoDto){
			
			ExamDetail exam = edRepo.getOneExam(examInfoDto.getExamSpecialization(), examInfoDto.getExamLevel());
			List<QuestionsDetail> questionList = qdRepo.getQuestions(exam.getExamid());
			Set<QuestionDetailsDto> questionListDto = new HashSet<QuestionDetailsDto>();
			
			for(QuestionsDetail question: questionList) {
				
				QuestionDetailsDto questionDetailDto = new QuestionDetailsDto();
				questionDetailDto.setQuestionid(question.getQuestionid());
				questionDetailDto.setQuestion(question.getQuestion());
				questionDetailDto.setOptionA(question.getOptiona());
				questionDetailDto.setOptionB(question.getOptionb());
				questionDetailDto.setOptionC(question.getOptionc());
				questionDetailDto.setOptionD(question.getOptiond());
				questionDetailDto.setExamLevel(examInfoDto.getExamLevel());
				questionDetailDto.setExamSpecialization(examInfoDto.getExamSpecialization());
				questionDetailDto.setExamTime(examInfoDto.getExamTime());
				
				questionListDto.add(questionDetailDto);
			}
			return questionListDto;		
	}
	
	@Override//will return all the available exams 
	public Set<ExamInformationDto> selectExamsService(){
		
		List<ExamDetail> allExams = edRepo.getAllExams();
		
		Set<ExamInformationDto> allExamsDto = new HashSet<ExamInformationDto>();
		
		for(ExamDetail exam : allExams) {
			ExamInformationDto examInfoDto = new ExamInformationDto();
			
			examInfoDto.setExamLevel(exam.getExamLevel());
			examInfoDto.setExamSpecialization(exam.getExamSpecialization());
			examInfoDto.setExamTime(exam.getTime());
			examInfoDto.setPassingMark(exam.getPassingMark());
			
			allExamsDto.add(examInfoDto);
			
		}
		
		
		return allExamsDto;
		
	}
	
	@Override
	public String deleteQuestionsForExamService(DeleteQuestionsForExamDto dqeDto) throws OnlineExamException{
		
		
			try {
				ExamDetail exam = edRepo.getOneExam(dqeDto.getExamSpecialization(), dqeDto.getExamLevel());
				qdRepo.deleteQuestionsByExam(exam.getExamid());
				return "questions deleted";
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new OnlineExamException("Not deleted");
				
			
			}
		
	}
	

	@Override
	public ReportCardDto addResponsesService(AddResponsesForExamDto areDto) {
		
		//fetching responses list from the input object areDto.
		Set<ResponseInfoDto> riDtoList = areDto.getResponseList();
		
		//creating a new list for storing responses. Which is later used to calculate the marks and generate reportcard
		List<StudentRespons> srAddedList = new ArrayList<StudentRespons>();
		
		ExamDetail exam = edRepo.getOneExam(areDto.getExamSpecialization(), areDto.getExamLevel());
		
		//creating one integer to  store userid which will we useful in calling the "generateReportCard() function
		int userIdforReportCard=0;
		
		//for to fetch the each response from list of responseinfodto's which are from input(i.e, areDto) 
		//and will generate new student_responses object and will all responses to database.
		for (ResponseInfoDto responseInfoDto : riDtoList) {
			
			int userId = responseInfoDto.getUserId();
			int questionId = responseInfoDto.getQuestionId();
			
			UserDetail userDetail = udRepo.getOneUser(userId);
			QuestionsDetail questionsDetail = qdRepo.getOneQuestion(questionId);
		
			StudentRespons sr = new StudentRespons();
			
			sr.setUserDetail(userDetail);
			sr.setQuestionsDetail(questionsDetail);
			sr.setResponse(responseInfoDto.getResponse());
			String answer = questionsDetail.getAnswer();
			int responseStatus = 0;
			
			if(answer.equalsIgnoreCase(responseInfoDto.getResponse())) {	
				responseStatus = 1;
			}
			System.out.println("-------------------------------------------------------------------");
			System.out.println("Dto questionid : "+questionId);
			System.out.println("db questionid : "+questionsDetail.getQuestionid());
			System.out.println("Dto response : "+responseInfoDto.getResponse());
			System.out.println("db answer : "+questionsDetail.getAnswer());
			System.out.println("responsStatus : "+responseStatus);
			System.out.println("-------------------------------------------------------------------");
			
			sr.setQuestionStatus(responseStatus);
			//adding responses object to database by using studetnResponseRepo
			srRepo.addstudentresponses(sr);
			
			//fetching response which was added just now and adding to the list. This list for each student and for each question.
			//Here weare adding response from dto to database. and fetching the same one from databse to a list
			//As after writing the exam user will call this function. So responses will be added to database for particular exam.
			//Even though we are fetching based on questionsid and userid, but still we are fetching in same for loop in which we are adding
			//so the responses which are fetched are belong the this exam only.
			StudentRespons studentRespons = srRepo.getsingleresponse(userId,questionId );
			srAddedList.add(studentRespons);
			
			//assigning userid to use is in generating report card method
			userIdforReportCard = userId;
		}
		
		//Using the list generated in the above for loop. generating the reportcard
		rcSer.generateReportCard(exam.getExamid(), userIdforReportCard);
		
		//In reportcard repo we have method to fetch list of reportcards for a user. List is because a user can write more than one exam and he can have
		//more thatn one report card. But here we are alaso passing the bothe examspec and exam level so this for loop is useful for fetching only single
		//report of a user for a exam.
		Set<ReportCardDto> rcList = rcSer.getReportCardService(userIdforReportCard);
		ReportCardDto rcForThisExam = new ReportCardDto();
		
		//for loop to get the exact reportcard for the required examid, and userid(which is actually submitted at time itself and report also will be displayed
		//at that time only
		
		for(ReportCardDto rcDto : rcList) {
			int rcDtoExamID = edRepo.getOneExam(rcDto.getExamSpec(), rcDto.getExamLevel()).getExamid();
			if(exam.getExamid() == rcDtoExamID) {
				
				rcForThisExam = rcDto;
			}
		}
		return rcForThisExam;
	}
	
	


}
