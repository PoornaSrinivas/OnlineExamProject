package com.repo.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;

@SpringBootTest
class AdminLoginRepoTest {
	
	@Autowired
	AdminLoginRepo alRepo;
	
	//to get one  admin details
	@Test//imp1
	void contextLoad1() {		
		String email = "manju@gmail.com";
		AdminLogin alRef = alRepo.getAdmin(email); 
		System.out.println("---------------------------------------------");
		System.out.println("Admin Details:");
		System.out.println("Admin Email	: "+alRef.getEmail());
		System.out.println("Admin Password	: "+alRef.getPassword());
		System.out.println("---------------------------------------------");
	}
}