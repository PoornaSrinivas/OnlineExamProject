package com.layer2.entity;

import java.io.Serializable;
import javax.persistence.*;



/**
 * The persistent class for the STUDENT_RESPONSES database table.
 * 
 */
@Entity
@Table(name="STUDENT_RESPONSES")
@NamedQuery(name="StudentRespons.findAll", query="SELECT s FROM StudentRespons s")
public class StudentRespons implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int responseid;

	@Column(name="QUESTION_STATUS")
	private int questionStatus;

	private String response;

	//bi-directional many-to-one association to QuestionsDetail
	@ManyToOne
	@JoinColumn(name="QUESTIONID")
	private QuestionsDetail questionsDetail;

	//bi-directional many-to-one association to UserDetail
	@ManyToOne
	@JoinColumn(name="USERID")
	private UserDetail userDetail;

	public StudentRespons() {
	}

	public int getResponseid() {
		return this.responseid;
	}

	public void setResponseid(int responseid) {
		this.responseid = responseid;
	}

	public int getQuestionStatus() {
		return this.questionStatus;
	}

	public void setQuestionStatus(int questionStatus) {
		this.questionStatus = questionStatus;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public QuestionsDetail getQuestionsDetail() {
		return this.questionsDetail;
	}

	public void setQuestionsDetail(QuestionsDetail questionsDetail) {
		this.questionsDetail = questionsDetail;
	}

	public UserDetail getUserDetail() {
		return this.userDetail;
	}

	public void setUserDetail(UserDetail userDetail) {
		this.userDetail = userDetail;
	}

	@Override
	public String toString() {
		return "StudentRespons [responseid=" + responseid + ", questionStatus=" + questionStatus + ", response="
				+ response + "]";
	}
	
}