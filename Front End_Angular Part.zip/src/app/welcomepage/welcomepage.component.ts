import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { OnlineexamService } from '../onlineexam.service';
import { ReportCardDto } from '../ReportCardDto';
import { SendObjectService } from '../send-object.service';
import { UserInfoDto } from '../UserInfoDto';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcomepage',
  templateUrl: './welcomepage.component.html',
  styleUrls: ['./welcomepage.component.css']
})
export class WelcomepageComponent implements OnInit {

  userInfoDto : UserInfoDto = new UserInfoDto();
  reportCardList : any;
  userId : number;
  
  constructor( private sendService: SendObjectService,
               private service : OnlineexamService
    ) { }

  ngOnInit(): void {
    this.userInfoDto = JSON.parse(sessionStorage.getItem("myUser"));
    
    
  } 

 


}
