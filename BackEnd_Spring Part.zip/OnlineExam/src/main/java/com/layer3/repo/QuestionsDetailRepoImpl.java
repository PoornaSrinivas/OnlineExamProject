package com.layer3.repo;
import com.layer2.entity.*;


import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;






@Repository
public class QuestionsDetailRepoImpl implements QuestionsDetailRepo {
	
	@PersistenceContext
	EntityManager entityManager;

	@Transactional//imp1
	public List<QuestionsDetail> getQuestions(int examId) {		
		System.out.println("----------------------------------------------------");
		System.out.println("GetQuestions() is called");
		System.out.println("----------------------------------------------------");
		
		Query query =  entityManager.createQuery("FROM QuestionsDetail  WHERE examid="+examId);		 
		List<QuestionsDetail> quesList = query.getResultList();
		return quesList;		
	}
	
	@Transactional//imp2
	public QuestionsDetail getOneQuestion(int qId) {		
		QuestionsDetail question = entityManager.find(QuestionsDetail.class, qId);
		
		return question;
		
		
	}

	@Transactional//imp3
	public void addQuestion(QuestionsDetail question) {
		entityManager.persist(question);
	}
	

	
	
	
	  @Transactional 
	  public void deleteQuestion(int questionId) {
		  System.out.println("------------------------------------------");
		  System.out.println("deleteQuestion() called");
		  System.out.println("------------------------------------------");
		  
		  
		  QuestionsDetail question = entityManager.find(QuestionsDetail.class, questionId);
		  entityManager.remove(question);
		  
		  
		  
		  System.out.println("------------------------------------------");
		  System.out.println("removed using entity manager");
		  System.out.println("------------------------------------------"); }
	 
	
	
	@Transactional//imp4
	public void deleteQuestionByHql(int questionId) {
		Query query=entityManager.createQuery(" delete from QuestionsDetail where questionid= "+questionId);
		int rowsDeleted=query.executeUpdate();
		System.out.println("------------------------------------------");
		System.out.println("removed the question");
		System.out.println("------------------------------------------");
	}
		
	

	
	
	
	  @Transactional //imp5
	  public void updateQuestion(QuestionsDetail question) {
			System.out.println("--------------------------------------------------");
			System.out.println("updateQuestion() called");
			System.out.println("--------------------------------------------------");
		    entityManager.merge(question);
			System.out.println("--------------------------------------------------");
			System.out.println("updated the question ");
			System.out.println("--------------------------------------------------");
	  
	  }
	  
	  @Transactional//imp7
	  public void deleteQuestionsByExam(int examId) {
		  
		  Query query=entityManager.createQuery("delete from QuestionsDetail where examid="+examId);
		  int rowsDeleted=query.executeUpdate();
		  System.out.println("------------------------------------------");
		  System.out.println("No of question removed : "+rowsDeleted);
		  System.out.println("removed questions in the exam : "+examId);
		  System.out.println("------------------------------------------");
		  
		  
	  }


}
