import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminwelcompageComponent } from './adminwelcompage.component';

describe('AdminwelcompageComponent', () => {
  let component: AdminwelcompageComponent;
  let fixture: ComponentFixture<AdminwelcompageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminwelcompageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminwelcompageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
