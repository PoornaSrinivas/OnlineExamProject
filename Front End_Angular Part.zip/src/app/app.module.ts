import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExampageComponent } from './exampage/exampage.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportcardComponent } from './reportcard/reportcard.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { OldreportcardComponent } from './oldreportcard/oldreportcard.component';
import { AddquestionsComponent } from './addquestions/addquestions.component';
import { DeletequestionsComponent } from './deletequestions/deletequestions.component';
import { SelectexampageComponent } from './selectexampage/selectexampage.component';
import { AdminwelcompageComponent } from './adminwelcompage/adminwelcompage.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { SearchstudentsComponent } from './searchstudents/searchstudents.component';

@NgModule({
  declarations: [
    AppComponent,
    ExampageComponent,
    ReportcardComponent,
    LoginComponent,
    OldreportcardComponent,
    AddquestionsComponent,
    DeletequestionsComponent,
    SelectexampageComponent,
    AdminwelcompageComponent,
    AboutusComponent,
    RegisterpageComponent,
    ResetpasswordComponent,
    SearchstudentsComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule ,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
