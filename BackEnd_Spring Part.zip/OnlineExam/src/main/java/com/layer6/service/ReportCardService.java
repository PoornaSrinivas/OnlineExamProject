package com.layer6.service;

import java.util.List;
import java.util.Set;

import com.layer2.entity.StudentRespons;
import com.layer4.dto.*;
import com.layer5.exception.OnlineExamException;

public interface ReportCardService {
	public Set<ReportCardDto> getReportCardService(int userId);
	public Set<UserInfoDto> searchStudentService(SearchStudentDto ssDto);
	public String generateReportCard(int examid, int userid);


}
