package com.layer2.entity;


import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the REPORT_CARD database table.
 * 
 */
@Entity
@Table(name="REPORT_CARD")
@NamedQuery(name="ReportCard.findAll", query="SELECT r FROM ReportCard r")
public class ReportCard implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int reportid;

	
	@Column(name="EXAM_DATE")
	private LocalDate examDate = LocalDate.now();

	private int marks;

	private String status;

	//bi-directional many-to-one association to ExamDetail
	@ManyToOne
	@JoinColumn(name="EXAMID")
	private ExamDetail examDetail;

	//bi-directional many-to-one association to UserDetail
	@ManyToOne
	@JoinColumn(name="USERID")
	private UserDetail userDetail;

	public ReportCard() {
	}

	public int getReportid() {
		return this.reportid;
	}

	public void setReportid(int reportid) {
		this.reportid = reportid;
	}

	public LocalDate getExamDate() {
		return this.examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public int getMarks() {
		return this.marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ExamDetail getExamDetail() {
		return this.examDetail;
	}

	public void setExamDetail(ExamDetail examDetail) {
		this.examDetail = examDetail;
	}

	public UserDetail getUserDetail() {
		return this.userDetail;
	}

	public void setUserDetail(UserDetail userDetail) {
		this.userDetail = userDetail;
	}

	@Override
	public String toString() {
		return "ReportCard [reportid=" + reportid + ", examDate=" + examDate + ", marks=" + marks + ", status=" + status
				+ "]";
	}
	
}