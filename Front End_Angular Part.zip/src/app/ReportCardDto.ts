export class ReportCardDto {

	fullName : string;
	marks: number;
	examLevel : string					
	examSpec : string
    status : string
    
}