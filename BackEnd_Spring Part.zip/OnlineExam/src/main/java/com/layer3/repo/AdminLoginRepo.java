package com.layer3.repo;

import org.springframework.stereotype.Repository;

import com.layer2.entity.*;

@Repository
public interface AdminLoginRepo  {
	
	
	public AdminLogin getAdmin(String email);

}
