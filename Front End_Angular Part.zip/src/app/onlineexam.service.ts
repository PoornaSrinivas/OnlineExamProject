import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ExamInformationDto } from './ExamInformationDto';
import { Observable } from 'rxjs';
import { QuestionDetailsDto } from './QuestionDetailsDto';
import { AddResponsesForExamDto } from './AddResponsesForExamDto';
import { ReportCardDto } from './ReportCardDto';
import { UserLoginDto } from './UserLoginDto';
import { AdminLoginDto } from './AdminLoginDto';
import { AddquestionsForExamDto } from './AddQuestionsForExamDto';
import { stringify } from '@angular/compiler/src/util';
import { DeleteQuestionsForExamDto } from './DeleteQuestionsForExamDto';
import { SearchStudentDto } from './SearchStudentDto';
import { UserInfoDto } from './UserInfoDto';
import { ResetPasswordDto } from './ResetPasswordDto';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { UserRegisterDto } from './UserRegisterDto';

@Injectable({
  providedIn: 'root'
})
export class OnlineexamService {

  constructor(private http: HttpClient) {}

  getUser(userLoginDto : UserLoginDto) : Observable<any>{
      let url = 'http://localhost:8090/userlogin';
      return this.http.post<UserLoginDto>(url,userLoginDto);   
    }

  getAdmin(adminLoginDto : AdminLoginDto) : Observable<any>{
    let url = 'http://localhost:8090/adminlogin';
    return this.http.post<AdminLoginDto>(url,adminLoginDto);
  }

  getQuestionsForExam(examInformationDto: ExamInformationDto):Observable<any>{
     let url = 'http://localhost:8090/getquestionsforexam';
     return this.http.post<QuestionDetailsDto[]>(url,examInformationDto);    
   }

  addResponses(addResponsesForExamDto: AddResponsesForExamDto):Observable<any>{
    let url = 'http://localhost:8090/addresponses';
    return this.http.post<ReportCardDto>(url,addResponsesForExamDto);    
   }

   getReportCardsOfUser(userId: number):Observable<any>{
    let url = 'http://localhost:8090/getreportcard/'+userId;
    return this.http.get<ReportCardDto[]>(url);    
   }

   addQuestionsForExam(addquestionsForExamDto : AddquestionsForExamDto ):Observable<any>{
     let url = 'http://localhost:8090/addquestionsforexam/';
     return this.http.post<any>(url,addquestionsForExamDto);
   }

   deleteQuestionsForExam(deleteQuestionsForExam : DeleteQuestionsForExamDto):Observable<any>{
    let url = 'http://localhost:8090/deletequestionsforexam/';
    return this.http.post<string>(url,deleteQuestionsForExam,{responseType:'json'});
   }

   serachStudentService(searchStudentDto : SearchStudentDto):Observable<any>{
    let url = 'http://localhost:8090/searchstudentsinfo/';
    return this.http.post<UserInfoDto[]>(url,searchStudentDto);
   }

   resetPasswordService(resetPasswordDto : ResetPasswordDto):Observable<any>{
    let url = 'http://localhost:8090/resetpassword/';
    return this.http.put<Message>(url,resetPasswordDto);
   }

   registerUserService(userRegisterDto : UserRegisterDto):Observable<any>{
    let url = 'http://localhost:8090/registeruser/';
    return this.http.post<Message>(url,userRegisterDto);
   }
}
