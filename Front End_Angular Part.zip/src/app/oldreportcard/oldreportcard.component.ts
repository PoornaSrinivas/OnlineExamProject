import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineexamService } from '../onlineexam.service';
import { ReportCardDto } from '../ReportCardDto';
import { UserInfoDto } from '../UserInfoDto';

@Component({
  selector: 'app-oldreportcard',
  templateUrl: './oldreportcard.component.html',
  styleUrls: ['./oldreportcard.component.css']
})
export class OldreportcardComponent implements OnInit {
  
  userInfoDto : UserInfoDto = new UserInfoDto(); 
  reportCardList : any;
  userId : number;

  constructor(private service:OnlineexamService,
              private router: Router        
  ) { }

  ngOnInit(): void {
    if(JSON.parse(sessionStorage.getItem("myUser")) == null){
      console.log("Login first")
      alert('Please login')
      this.router.navigate(['login']);
    }else{
      this.reportCardsOfUser();
      this.userInfoDto = JSON.parse(sessionStorage.getItem("myUser"));
      console.log(this.userInfoDto)
      this.reportCardsOfUser();
     sessionStorage.setItem("reportCardList", JSON.stringify(this.reportCardList));  
     }
   
    
  }

  reportCardsOfUser(){
    
    this.userId = this.userInfoDto.userId;
    this.service.getReportCardsOfUser(this.userId).subscribe(data => {
    this.reportCardList=data;
    console.log(this.reportCardList)
    })
  }
}
