import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { ReportCardDto } from '../ReportCardDto';
import { SendObjectService } from '../send-object.service';

@Component({
  selector: 'app-reportcard',
  templateUrl: './reportcard.component.html',
  styleUrls: ['./reportcard.component.css']
})
export class ReportcardComponent implements OnInit {

  reportCard : ReportCardDto=new ReportCardDto();

  constructor( private sendService: SendObjectService,
               private router : Router      
    ) { }

  ngOnInit(): void {

    this.sendService.sendObject.subscribe(obj=>{
      this.reportCard = obj;
      //console.log(obj);
      console.log(this.reportCard);
     
    })

  }

  nextStep(){
    if(this.reportCard.status==" FAIL"){
      alert("You have not cleared the exam")
      this.logout();
    }
    else{
      alert("Congratulations, You have cleared the exam. Please attempt the next level")
      this.router.navigate(['selectexam'])
    }

  }
  logout(){
    sessionStorage.clear();
    this.router.navigate(['welcome']);
  }
  
}
