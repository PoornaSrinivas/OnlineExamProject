package com.repo.test;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;



@SpringBootTest
class ReportCardRepoTest {




@Autowired
ReportCardRepo rcRepo;



@Autowired
UserDetailRepo udRepo;


@Autowired
ExamDetailRepo edRepo;

@Autowired
StudentResponsRepo srRepo;

@Autowired
QuestionsDetailRepo qRepo;

	//To remove a reportcard by reportID
	@Test
	void contextLoads1()
	{
		int rId = 304;
	
		rcRepo.removeReportCard(rId);
		System.out.println("removereport ");
		
	}

	//select query for all reportcards
	@Test
	void  contextLoads2() {                
		
		List<ReportCard> report = rcRepo.getAllReportCards();
		                                    
		System.out.println("ReportCardlist");
		for (ReportCard reportCard : report) {
			System.out.println("----------------------------------------------------");	
			System.out.println("report card details: "+reportCard);
			System.out.println("Print exam id :"+reportCard.getExamDetail().getExamid());
			System.out.println("Print user id :"+reportCard.getUserDetail().getUserid());
			System.out.println("----------------------------------------------------");
			}
	}

	@Test//to get reportcards of a user
	void  contextLoads8() {                
		
		int userid = 1;
		List<ReportCard> report = rcRepo.getReportCards(userid);
		                                    
		System.out.println("ReportCardlist");
		for (ReportCard reportCard : report) {
			System.out.println("----------------------------------------------------");	
			System.out.println("report card details: "+reportCard);
			System.out.println("Print exam id :"+reportCard.getExamDetail().getExamid());
			System.out.println("Print user id :"+reportCard.getUserDetail().getUserid());
			System.out.println("----------------------------------------------------");
			}
	}

	@Test  //to add a reportcard
	void contextLoads3()
	{
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.sql.Date sqlDate = null;
			String date = "06-09-2003";
			if( !date.isEmpty()) {
				try {
					java.util.Date normalDate = sdf1.parse(date);
					sqlDate = new java.sql.Date(normalDate.getTime());
				} catch (ParseException e) {        
				}
			}
            UserDetail ud = udRepo.getOneUser(3);
            ExamDetail ed = edRepo.getOneExam(53);
			ReportCard rc = new ReportCard();
			//rc.setReportid(309);

			
			rc.setMarks(5);
			rc.setStatus("PASS");
			rc.setExamDetail(ed);
			rc.setUserDetail(ud);
			

			rcRepo.addReportCard(rc);
			System.out.println("--------------------------------------------------------");
			System.out.println("Add report Card() is called..");
			System.out.println("Add report Card() is called :"+rc);
			System.out.println("--------------------------------------------------------");
	}

	@Test  //To create report card of a examid for a user
	void contextLoads4()
	{
		//exam=57;
		int examid = 51;
		int userid = 3;
		int marks = 0;
		String status = null;
		ExamDetail exam = edRepo.getOneExam(examid);
		UserDetail user = udRepo.getOneUser(userid);
		List<QuestionsDetail> qList = qRepo.getQuestions(examid);
		List<StudentRespons> respList = srRepo.getResponses(userid);
		List<StudentRespons> rList = new ArrayList<StudentRespons>();
		
		for(StudentRespons sr : respList) {
		   int srqid = sr.getQuestionsDetail().getQuestionid();
			for(QuestionsDetail qd : qList){
		        if(srqid == qd.getQuestionid()) {
		        	rList.add(sr);
		        	break;
		                
		        }            
		    }
		}
		for(StudentRespons sr : rList) {
			marks = marks+sr.getQuestionStatus();
		}
		System.out.println("---------------------------------------");
		System.out.println("Marks obtained : "+marks);
		System.out.println("---------------------------------------");
		
		if(marks < exam.getPassingMark()) {
			status = "'FAIL'";
		}
		else {
			status="'PASS'";
		}
		
		/*
		 * SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy"); java.sql.Date
		 * sqlDate = null; String date = "14-09-2017"; if( !date.isEmpty()) { try {
		 * java.util.Date normalDate = sdf1.parse(date); sqlDate = new
		 * java.sql.Date(normalDate.getTime()); } catch (ParseException e) { } }
		 */
		
		ReportCard newRC = new ReportCard();
		newRC.setExamDetail(exam);
		newRC.setMarks(marks);
		newRC.setStatus(status);
		newRC.setUserDetail(user);
		
		rcRepo.addReportCard(newRC);
		System.out.println("----------------------------------------------------");
		System.out.println("ReportCard added : "+newRC);
		System.out.println("----------------------------------------------------");
	}

}
