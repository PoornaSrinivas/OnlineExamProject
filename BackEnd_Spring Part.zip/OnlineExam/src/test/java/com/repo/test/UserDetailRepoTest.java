package com.repo.test;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;



@SpringBootTest
class UserDetailRepoTest {

	@Autowired
	UserDetailRepo udRepo;
		


	@Test //getallusers
	void contextLoads1() {
	List<UserDetail> userlist = new ArrayList<UserDetail>();
	userlist = udRepo.getAllUsers();
	System.out.println("user details");
	for (UserDetail userDetail : userlist) {
		System.out.println("user details : "+userDetail);
	}
	}
	@Test //get single user
	void contextLoads2() {
		UserDetail ref = udRepo.getOneUser(1);
	 
		 System.out.println("getOneUser() is called");
		 /*
	     System.out.println(ref.getEmail());
		 System.out.println(ref.getPassword());
		 System.out.println(ref.getFullname());
		 System.out.println(ref.getMobile());
		 System.out.println(ref.getDateOfBirth());
		 System.out.println(ref.getCity());
		 System.out.println(ref.getState());
		 System.out.println(ref.getQualification());
		 System.out.println(ref.getYearOfCompletion());
		 */
		 System.out.println("User Details : "+ref);
		 System.out.println("=====================================");
	}
	
	@Test //add NewUser
	void contextLoads3() {
			
			String date = "13-06-1996";
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.sql.Date sqlDate = null;
			if( !date.isEmpty()) {
				try {
					java.util.Date normalDate = sdf1.parse(date);
					sqlDate = new java.sql.Date(normalDate.getTime());
				} catch (ParseException e) {         
				}
			} 
		
		UserDetail ref = new UserDetail();
		
		ref.setEmail("rajini@gmail.com");
		ref.setPassword("raj@123");
		ref.setFullname("rajkumari");
		ref.setMobile("9090867675");
		 
		ref.setCity("PUNE");
		ref.setState("MH");
		ref.setQualification("B.TECH");
		ref.setYearOfCompletion(2019);
		
		udRepo.addUser(ref);
		
		System.out.println("New user Added.......");
		
	}
	
	@Test //update email 
	void contextloads4() {
		try {
			udRepo.updateUserEmail(132, "rajkumar@gmaail.com");
			System.out.println("Updated Email successfully.....");
		} catch (Exception e) {
			System.out.println("Message: user doesn't exist ");
		}
	}
	
	@Test//updat mobile number
	void contextloads5() {
		try {
			udRepo.updateUserMobilNumber(132, "9876543210");
			System.out.println("Updated MobileNumber successfully.....");
		} catch (Exception e) {
			System.out.println("Message: user doesn't exist ");
		}
	}
	

	@Test//update user password
	void contextloads6() {
		try {
			udRepo.updateUserPassword(132, "Manju@devil");
			System.out.println("Updated Password successfully.....");
		} catch (Exception e) {
			System.out.println("Message: user doesn't exist ");
		}
	}
	
	@Test//delete user
	void contextloads7() {
		
		udRepo.removeUser(132);
		System.out.println("Deleted sucessfully...........");
	}
	
	@Test//
	void contextloads9() {
		
		List<UserDetail> singleuser = null;
		singleuser=udRepo.getuser(1);
		for (UserDetail userDetail : singleuser) {
			System.out.println("userdetail : "+userDetail);
		}
	}
	
	@Test
	void contextloads8() {
		List<UserDetail> user = null;
		user = udRepo.getuserswithstateandcity("'AP'", "'KKD'");
		
		
		for (UserDetail userDetail : user) {
			System.out.println("userdetail : "+userDetail);
		}		
	}
	
	@Test
	void contextloads91() {
		String email = "Srinivas@gmail.com";
		UserDetail udRef = udRepo.getOneUser(email);
		System.out.println("-----------------------------------------------");
		System.out.println("udRef	: "+udRef);
		System.out.println("Userid	: "+udRef.getUserid());
		System.out.println("Email	: "+udRef.getEmail());
		System.out.println("Password: "+udRef.getPassword());
		System.out.println("-----------------------------------------------");
		
	}

}
