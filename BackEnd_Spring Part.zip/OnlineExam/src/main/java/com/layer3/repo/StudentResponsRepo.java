package com.layer3.repo;

import java.util.List;

import com.layer2.entity.*;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentResponsRepo {
	
	//StudentResponses Operations
	 
		public List<StudentRespons> getResponses(int userId); 	   //1. to get a single student response using userid
		public List<StudentRespons> getallresponses();		       //2. to get all the responses
		public void addstudentresponses(StudentRespons resp);	   //3. to add the new student responses depend upon user id
		public void removeStudentresponse(int responseId);	       //4. to remove a student response
		public  StudentRespons getsingleresponse(int userid, int questionid);  //to get a single student response
	
	
	
	
}


