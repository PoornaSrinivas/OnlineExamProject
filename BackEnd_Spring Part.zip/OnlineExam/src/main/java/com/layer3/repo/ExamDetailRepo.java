package com.layer3.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.layer2.entity.ExamDetail;

@Repository
public interface ExamDetailRepo {

	//ExamDetail Operations
		public ExamDetail getOneExam(int ExamId);
		public List<ExamDetail> getAllExams();
		public void addExam(ExamDetail ref);
		public void removeExam(int ExamId);
		public ExamDetail getOneExam(String examspecialization, String examlevel);
}
