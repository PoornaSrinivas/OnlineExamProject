package com.repo.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;

@SpringBootTest
class QuestionsDetailRepoTest {

	@Autowired
	UserDetailRepo udRepo;
	
	@Autowired
	ExamDetailRepo eRepo;
	
	@Autowired
	StudentResponsRepo srRepo;
	
	@Autowired
	QuestionsDetailRepo qRepo;
	
	//to get questions of a particular examId
	@Test//imp1
	void contextLoads1() {		
		List<QuestionsDetail> quesList = new ArrayList<QuestionsDetail>();
		quesList = qRepo.getQuestions(57);
		System.out.println("--------------------------------------------");
		System.out.println("QuestionsDetails");
		System.out.println("--------------------------------------------");
		
		for(QuestionsDetail q : quesList) {		
			System.out.println("QuestionID 	: "+q.getQuestionid());
			System.out.println("Question 	: "+q.getQuestion());
			System.out.println("OptionA 	: "+q.getOptiona());
			System.out.println("OptionB 	: "+q.getOptionb());
			System.out.println("OptionC		: "+q.getOptionc());
			System.out.println("OptionD 	: "+q.getOptiond());
			System.out.println("Answer 		: "+q.getAnswer());
			System.out.println("Exam 		: "+q.getExamDetail().getExamid());
			System.out.println("------------------------------------------");		
		}	
	}
	
	
	
	//To get a ONE question
	@Test//imp2
	void contextLoads2() {
		
		int qId = 7;
		QuestionsDetail q = new QuestionsDetail();
		q = qRepo.getOneQuestion(qId);
		System.out.println("-------------------------------------------------------");
		System.out.println("Question with id :"+qId+"---"+q);
		System.out.println("Exam : "+q.getExamDetail().getExamid());
		System.out.println("-------------------------------------------------------");
		
	}
	//to ADD a question
	@Test//imp3
	void contextLoads3() {
			
		ExamDetail exam = eRepo.getOneExam(53);
		System.out.println("------------------------------------------");
		System.out.println("Exam---53--: "+exam);
		System.out.println("------------------------------------------");
		
		QuestionsDetail q = new QuestionsDetail();
		q.setQuestion("trying new");
		q.setOptiona("A");
		q.setOptionb("B");
		q.setOptionc("C");
		q.setOptiond("D");
		q.setAnswer("C");
		q.setExamDetail(exam);
		qRepo.addQuestion(q);
		System.out.println("------------------------------------------");
		System.out.println("Question added");
		System.out.println("------------------------------------------");	
		
	}
	
	
	//To delete a question by question id
	@Test//imp4
	void contextLoads4() {
		int questionToDelete = 38; //question id to delete
		//qRepo.deleteQuestion(questionToDelete);
		System.out.println("------------------------------------------");
		System.out.println("Question  : "+qRepo.getOneQuestion(questionToDelete));
		System.out.println("Question in exam : "+qRepo.getOneQuestion(questionToDelete).getExamDetail().getExamid());
		System.out.println("------------------------------------------");
		
		
		qRepo.deleteQuestionByHql(questionToDelete);
		//qRepo.deleteQuestion(questionToDelete);
		
		
		System.out.println("------------------------------------------");
		System.out.println("Question deleted");
		System.out.println("------------------------------------------");
	 
		
	}
	
	//to update question by MERGE
	 @Test //imp5
	 void contextLoads5() {
	 
		 ExamDetail exam = eRepo.getOneExam(53);
		 QuestionsDetail q = new QuestionsDetail();
		 q.setQuestionid(7);
		 q.setQuestion("now changed7");
		 q.setOptiona("g"); 
		 q.setOptionb("g");
		 q.setOptionc("g");
		 q.setOptiond("g");
		 q.setAnswer("g");
		 q.setExamDetail(exam);
		 qRepo.updateQuestion(q);
		 System.out.println("------------------------------------------");
		 System.out.println("Question updated this is test");
		 System.out.println("------------------------------------------");
	  
	  }
	 
	
	 	//to add set of question for a exam
		@Test//imp6
		void contextLoads6() {
				
			ExamDetail exam = eRepo.getOneExam(53);
			System.out.println("------------------------------------------");
			System.out.println("Exam---53--: "+exam);
			System.out.println("------------------------------------------");
			
			Set<QuestionsDetail> questExam = new HashSet<QuestionsDetail>();
	
			QuestionsDetail q1 = new QuestionsDetail();
			QuestionsDetail q2 = new QuestionsDetail();
			QuestionsDetail q3 = new QuestionsDetail();
			//q.setQuestionid(123);
			q1.setQuestion("q1 for exam48"); q1.setOptiona("A"); q1.setOptionb("B"); q1.setOptionc("C"); q1.setOptiond("D"); q1.setAnswer("C"); q1.setExamDetail(exam);
			q2.setQuestion("q2 for exam48"); q2.setOptiona("A"); q2.setOptionb("B"); q2.setOptionc("C"); q2.setOptiond("D"); q2.setAnswer("B"); q2.setExamDetail(exam);
			q3.setQuestion("q3 for exam48"); q3.setOptiona("A"); q3.setOptionb("B"); q3.setOptionc("C"); q3.setOptiond("D"); q3.setAnswer("A"); q3.setExamDetail(exam);
			
			questExam.add(q1); questExam.add(q2); questExam.add(q3);
			
	
			for(QuestionsDetail q : questExam) {
				qRepo.addQuestion(q);
				System.out.println("------------------------------------------");
				System.out.println("Questions added");
				System.out.println("------------------------------------------");
			}
				
		}
		
		
	 	//to delete set of question for a exam
		@Test//imp7
		void contextLoads7() {
			
			int examId = 56; //examId = exam id to delete all the questions in it.
			qRepo.deleteQuestionsByExam(examId);
		}
		
		
		
		
}
