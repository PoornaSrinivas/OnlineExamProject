import { QuestionDetailsDto } from "./QuestionDetailsDto";

export class AddQuestionDto extends QuestionDetailsDto  {
	

    answer : string;
}