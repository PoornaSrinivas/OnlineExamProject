package com.repo.test;



import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.ExamDetail;
import com.layer2.entity.StudentRespons;
import com.layer3.repo.ExamDetailRepo;
import com.layer3.repo.UserDetailRepo;



@SpringBootTest
class ExamDetailRepoTest {

	@Autowired
	ExamDetailRepo eRepo;

	// get all exam details
	@Test
	void contextLoads1() {
		List<ExamDetail> Examlist = new ArrayList<ExamDetail>();
		Examlist = eRepo.getAllExams();
		System.out.println("Examlist");
		for (ExamDetail examDetail : Examlist) {
			System.out.println("exam details : "+examDetail);
		}
	}
	//add new exam
	@Test
	void contextLoads2() {
		
		//ed.setExamid(70);
		ExamDetail ed = new ExamDetail();
		ed.setExamSpecialization("azure");
		ed.setExamLevel("Level1");
		ed.setNumberOfQuestions(10);
		ed.setPassingMark(5);
		ed.setTime("01 hr");
		
		eRepo.addExam(ed);
	}
	
	@Test//get one exam
	void contextLoads3() {
		ExamDetail ref = new ExamDetail();
		ref =eRepo.getOneExam(22);
		System.out.println("getOneExam() is called");
		System.out.println("Exam Details: "+ref);
	}
	
	@Test//to remove exam
	void contextLoads4() {
		eRepo.removeExam(48);
		System.out.println("-------------------------------------------");
		System.out.println("deleted exam");
		System.out.println("-------------------------------------------");
	}
	
	@Test//to get exam based on specialization and level
	void contextLoad5() {
		
		String examspecialization = "JAVA";
		String examlevel = "LEVEL3";
		
		ExamDetail edref = eRepo.getOneExam(examspecialization, examlevel);
		
		System.out.println("-----------------------------------------------");
		System.out.println("edRef	: "+edref);
		System.out.println("Examid	: "+edref.getExamid());
		System.out.println("Number of Questions	: "+edref.getNumberOfQuestions());
		System.out.println("Passmarks: "+edref.getPassingMark());
		System.out.println("-----------------------------------------------");
		
	}
	
}
