import { Component, OnInit } from '@angular/core';
import { OnlineexamService } from '../onlineexam.service';
import { SearchStudentDto } from '../SearchStudentDto';

@Component({
  selector: 'app-searchstudents',
  templateUrl: './searchstudents.component.html',
  styleUrls: ['./searchstudents.component.css']
})
export class SearchstudentsComponent implements OnInit {

  searchStudentDto : SearchStudentDto = new SearchStudentDto();

  studentsInfo = [];
  
  states = ["ANDHRA PRADESH","TELANGANA","TAMIL NADU","MAHARASHTRA","KARNATAKA","GUJARAT","UTTAR PRADESH","PUNJAB","BIHAR","KERALA"]

  cities = ["VIZAG","HYDERABAD","CHENNAI","MUMBAI","BANGALORE","BARODA", "LUCKNOW",,"CHANDIGARH","PATNA","TRIVANDRUM"]

  exams = ["JAVA","PYTHON","SQL","PHP","C#/.NET","C/C++"];

  levels = ["LEVEL1","LEVEL2","LEVEL3"];

  marks = [10,9,8,7,6,5];

  constructor( private service : OnlineexamService) { }

  ngOnInit(): void {
  }

  searchStudent(){
    this.service.serachStudentService(this.searchStudentDto).subscribe(data=>{
      this.studentsInfo = data;
      console.log(this.studentsInfo)
    })
  } 
}
