export class ExamInformationDto {
	
	examSpecialization : String;
	examLevel : String
	examTime : String
    passingMark : String

}