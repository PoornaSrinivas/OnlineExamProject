package com.layer3.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.layer2.entity.*;

@Repository
public class AdminLoginRepoImpl  implements AdminLoginRepo{
	
	@PersistenceContext
	EntityManager EntityManager;

	@Transactional
	public AdminLogin getAdmin(String email) {

		AdminLogin adminLogin = EntityManager.find(AdminLogin.class, email);
		
		return adminLogin;
	}

}
