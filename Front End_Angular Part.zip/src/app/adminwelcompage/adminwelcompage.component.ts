import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminwelcompage',
  templateUrl: './adminwelcompage.component.html',
  styleUrls: ['./adminwelcompage.component.css']
})
export class AdminwelcompageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
