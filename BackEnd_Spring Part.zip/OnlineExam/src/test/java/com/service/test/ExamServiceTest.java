package com.service.test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.internal.build.AllowSysOut;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dto.*;
import com.layer5.exception.*;
import com.layer6.service.*;

@SpringBootTest
public class ExamServiceTest {
	
	@Autowired
	ExamService eSer;
	
	@Autowired
	ExamDetailRepo edRepo;
	
	@Autowired
	UserDetailRepo udRepo;
	
	@Test//To add questions to exam by useing addquestionstoexam()
	void contextLoads1() throws OnlineExamException {
		
		try {
			AddQuestionsForExamDto aqeDto = new AddQuestionsForExamDto();
			
			
			Set<AddQuestionDto> questionList = new HashSet<AddQuestionDto>(); 
			
			
			AddQuestionDto q1 = new AddQuestionDto();
			AddQuestionDto q2 = new AddQuestionDto();
			AddQuestionDto q3 = new AddQuestionDto();
			
			q1.setQuestion("Question for 54"); q1.setOptionA("A"); q1.setOptionB("B"); q1.setOptionC("C"); q1.setOptionD("D"); q1.setAnswer("B");
			q2.setQuestion("Question for 54"); q2.setOptionA("A"); q2.setOptionB("B"); q2.setOptionC("C"); q2.setOptionD("D"); q2.setAnswer("C");
			q3.setQuestion("Question for 54"); q3.setOptionA("A"); q3.setOptionB("B"); q3.setOptionC("C"); q3.setOptionD("D"); q3.setAnswer("A");
			
			questionList.add(q1); questionList.add(q2); questionList.add(q3);
			
			aqeDto.setExamLevel("LEVEL2");
			aqeDto.setExamSpecialization("PHP");
			aqeDto.setQuestionsList(questionList);
			
			eSer.addQuestionsForExamService(aqeDto);
		} catch (OnlineExamException e) {
			throw new OnlineExamException("Unable to add");
		}
	}
	
	
	
	@Test//To get questions for exam
	void contextLoads2() throws OnlineExamException {
		
		ExamInformationDto examInfoDto = new ExamInformationDto();
		String examSpec = "PYTHON";
		String examLevel = "LEVEL2";
		examInfoDto.setExamLevel(examLevel); examInfoDto.setExamSpecialization(examSpec);
		ExamDetail exam = edRepo.getOneExam(examSpec, examLevel);
		
		Set<QuestionDetailsDto> qList = eSer.getAllquestionsForExamService(examInfoDto);
		for(QuestionDetailsDto q: qList) {
			System.out.println("-----------------------------------------------------------------------------------------------");
			System.out.println("ExamDetails : "+exam);
			System.out.println("QuestionDetails : "+q);
			System.out.println("-----------------------------------------------------------------------------------------------");
		}
	}
	
	
	@Test//To get exams
	void contextLoads3(){
		
		List<ExamDetail> allExams = edRepo.getAllExams();
		for(ExamDetail e: allExams) {
			System.out.println("-----------------------------------------------");
			System.out.println("ExamDetail"+e);
			System.out.println("-----------------------------------------------");
		}
		
	}
	
	@Test//To delete all questions for exam
	void contextLoads4(){
		
		DeleteQuestionsForExamDto dqeDto = new DeleteQuestionsForExamDto();
		dqeDto.setExamLevel("LEVEL2");
		dqeDto.setExamSpecialization("PYTHON");
		try {
			eSer.deleteQuestionsForExamService(dqeDto);
		} catch (OnlineExamException e) {
			// TODO Auto-generated catch block
			System.out.println("-----------------------------------------------");
			System.out.println("Not deleted");
			System.out.println("-----------------------------------------------");
		}
	}
	
	@Test
	void contextLoads5() {
		
		AddResponsesForExamDto adDto = new AddResponsesForExamDto();
		
		ResponseInfoDto r1= new ResponseInfoDto();
		ResponseInfoDto r2= new ResponseInfoDto();
		ResponseInfoDto r3= new ResponseInfoDto();
		ResponseInfoDto r4= new ResponseInfoDto();
		ResponseInfoDto r5= new ResponseInfoDto();
		
		
		String el = "LEVEL1";
		String es = "JAVA";
		
		ExamDetail exam = edRepo.getOneExam(es, el);
		UserDetail user = udRepo.getOneUser(1);
		
		r1.setExamLevel(el); r1.setExamSpecialization(es); r1.setQuestionId(101); r1.setResponse("A"); r1.setUserId(1);
		r2.setExamLevel(el); r2.setExamSpecialization(es); r2.setQuestionId(102); r2.setResponse("B"); r2.setUserId(1);
		r3.setExamLevel(el); r3.setExamSpecialization(es); r3.setQuestionId(103); r3.setResponse("C"); r3.setUserId(1);
		r4.setExamLevel(el); r4.setExamSpecialization(es); r4.setQuestionId(104); r4.setResponse("D"); r4.setUserId(1);
		r5.setExamLevel(el); r5.setExamSpecialization(es); r5.setQuestionId(105); r5.setResponse("A"); r5.setUserId(1);
		
		Set<ResponseInfoDto> rsList = new HashSet<ResponseInfoDto>();
		
		rsList.add(r1); rsList.add(r2); rsList.add(r3); rsList.add(r4); rsList.add(r5);
		
		adDto.setExamLevel(el);
		adDto.setExamSpecialization(es);
		adDto.setResponseList(rsList);
	
		eSer.addResponsesService(adDto);
		System.out.println("---------------------------------------------------------------");
		System.out.println("responses are added : ");
		System.out.println("---------------------------------------------------------------");
		
	}
}
