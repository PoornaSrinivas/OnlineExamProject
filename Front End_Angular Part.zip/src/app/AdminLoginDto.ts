export class AdminLoginDto {

    adminEmail: string;					
	password: string;
	status: string;

    
}