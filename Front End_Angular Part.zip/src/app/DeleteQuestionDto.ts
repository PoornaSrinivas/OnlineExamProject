import { ExamInformationDto } from "./ExamInformationDto";

export class DeleteQuestionDto extends ExamInformationDto {

	
    questionId: number;
}