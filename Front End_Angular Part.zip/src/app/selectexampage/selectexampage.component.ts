import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserInfoDto } from '../UserInfoDto';

@Component({
  selector: 'app-selectexampage',
  templateUrl: './selectexampage.component.html',
  styleUrls: ['./selectexampage.component.css']
})
export class SelectexampageComponent implements OnInit {

  examSpec : string;
  examLevel : string;
  userInfoDto : UserInfoDto = new UserInfoDto();
  constructor(private router: Router,) { }

  ngOnInit(): void {
    
    // console.log(JSON.parse(sessionStorage.getItem("myUser")))
    if(JSON.parse(sessionStorage.getItem("myUser")) == null){
      console.log("Login first")
      alert('Please login')
      this.router.navigate(['login']);
    }else{
      this.selectedExam();
      
    }
  } 

  selectedExam(){
    
    sessionStorage.setItem("examSpec",this.examSpec);
    sessionStorage.setItem("examLevel",this.examLevel);
  }
}
 