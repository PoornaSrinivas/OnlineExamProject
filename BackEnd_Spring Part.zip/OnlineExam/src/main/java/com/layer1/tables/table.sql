



DROP TABLE Admin_Login cascade constraints;
DROP TABLE Student_Responses cascade constraints;
DROP TABLE Report_Card cascade constraints;
DROP TABLE Questions_Details cascade constraints;
DROP TABLE Exam_Details cascade constraints;
DROP TABLE User_Details cascade constraints;


CREATE TABLE User_Details (
   UserID  number(6) NOT NULL,
   Email   varchar2(25) NOT NULL,
   Password  varchar2(12) NOT NULL,
   FullName  varchar2(25) NOT NULL,
   Mobile    varchar2(10) NOT NULL,	
   Date_of_Birth  date NOT NULL,
   City    varchar2(15) NOT NULL,
   State   varchar2(15) NOT NULL,
   Qualification varchar2(10) NOT NULL,
   Year_of_completion   number(4) NOT NULL,
   constraint UserDetails_UserID_pk primary key(UserID));

INSERT INTO User_Details VALUES (1,'Srinivas@gmail.com','Srinu@124','Srinivas','9567898979','01-FEB-1996','VSKP','AP','B.TECH',2018);
INSERT INTO User_Details VALUES (2,'Anil@gmail.com','Anil@2729','Anil','9345898457','11-Jan-1996','KKD','AP','B.TECH',2018);
INSERT INTO User_Details VALUES (3,'Kaveri@gmail.com','Kaveri@235','Kaveri','9547898678','22-APR-1996','PTN','BIH','B.TECH',2018);
INSERT INTO User_Details VALUES (4,'Ravi@gmail.com','Ravi@1456','Ravi','8667898567','18-JUN-1994','VZM','AP','M.TECH',2018);


					

CREATE TABLE Admin_Login (
 Email varchar2(25) NOT NULL,
 Password varchar2(12) NOT NULL,
 CONSTRAINT AdminLogin_Email_PK PRIMARY KEY(Email));

INSERT INTO Admin_Login values('kalyan@gmail.com','kalyan');
INSERT INTO Admin_Login values('manju@gmail.com','manju');
(Email, Password)

CREATE TABLE Exam_Details (
 ExamID number(6) NOT NULL,
 Exam_Specialization varchar2(10) NOT NULL,
 Exam_level varchar2(7) NOT NULL,
 Number_Of_Questions number(3) NOT NULL,
 Passing_Mark number(3) NOT NULL,
 Time varchar2(10) NOT NULL,
 CONSTRAINT ExamDetails_ExamID_primary_key PRIMARY KEY (ExamID));


INSERT INTO Exam_Details values('51','JAVA','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('52','JAVA','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('53','JAVA','LEVEL3',5,3,'60 min');
INSERT INTO Exam_Details values('54','PYTHON','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('55','PYTHON','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('56','PYTHON','LEVEL3',5,3,'60 min');
INSERT INTO Exam_Details values('57','SQL','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('58','SQL','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('59','SQL','LEVEL3',5,3,'60 min');
INSERT INTO Exam_Details values('60','C/C++','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('61','C/C++','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('62','C/C++','LEVEL3',5,3,'60 min');
INSERT INTO Exam_Details values('63','PHP','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('64','PHP','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('65','PHP','LEVEL3',5,3,'60 min');
INSERT INTO Exam_Details values('66','C#/.NET','LEVEL1',5,3,'60 min');
INSERT INTO Exam_Details values('67','C#/.NET','LEVEL2',5,3,'60 min');
INSERT INTO Exam_Details values('68','C#/.NET','LEVEL3',5,3,'60 min');

CREATE TABLE Questions_Details(
 QuestionID NUMBER(6) NOT NULL,
 Question VARCHAR2(250)NOT NULL,
 OptionA VARCHAR2(50) NOT NULL,
 OptionB VARCHAR2(50) NOT NULL,
 OptionC VARCHAR2(50) NOT NULL,
 OptionD VARCHAR2(50) NOT NULL,
 Answer  VARCHAR2(5) NOT NULL,
 ExamID  NUMBER(6) NOT NULL,
 CONSTRAINT QUESTDET_QuestionID_PK PRIMARY KEY (QuestionID),
 CONSTRAINT QUESTDET_ExamID_FK FOREIGN KEY (ExamID) REFERENCES Exam_Details(ExamID));



INSERT INTO Questions_Details VALUES(101,'Java-level-1-Question-1','A','B','C','D','A',51);
INSERT INTO Questions_Details VALUES(102,'Java-level-1-Question-2','A','B','C','D','A',51);
INSERT INTO Questions_Details VALUES(103,'Java-level-1-Question-3','A','B','C','D','C',51);
INSERT INTO Questions_Details VALUES(104,'Java-level-1-Question-4','A','B','C','D','B',51);
INSERT INTO Questions_Details VALUES(105,'Java-level-1-Question-5','A','B','C','D','C',51);
INSERT INTO Questions_Details VALUES(106,'Java-level-2-Question-1','A','B','C','D','D',52);
INSERT INTO Questions_Details VALUES(107,'Java-level-2-Question-2','A','B','C','D','A',52);
INSERT INTO Questions_Details VALUES(108,'Java-level-2-Question-3','A','B','C','D','B',52);
INSERT INTO Questions_Details VALUES(109,'Java-level-2-Question-4','A','B','C','D','D',52);
INSERT INTO Questions_Details VALUES(110,'Java-level-2-Question-5','A','B','C','D','A',52);
INSERT INTO Questions_Details VALUES(111,'SQL-level-1-Question-1','A','B','C','D','C',57);
INSERT INTO Questions_Details VALUES(112,'SQL-level-1-Question-2','A','B','C','D','A',57);
INSERT INTO Questions_Details VALUES(113,'SQL-level-1-Question-3','A','B','C','D','B',57);
INSERT INTO Questions_Details VALUES(114,'SQL-level-1-Question-4','A','B','C','D','B',57);
INSERT INTO Questions_Details VALUES(115,'SQL-level-1-Question-5','A','B','C','D','D',57);



CREATE TABLE Student_Responses(
 ResponseID NUMBER(6) NOT NULL,
 UserID NUMBER(6) NOT NULL,
 QuestionID NUMBER(6) NOT NULL,
 Response VARCHAR2(7) NOT NULL,
 Question_Status NUMBER(1) NOT NULL,
 CONSTRAINT STUDRESP_ResponseID_PK PRIMARY KEY (ResponseID),
 CONSTRAINT STUDRESP_UserID_FK FOREIGN KEY (UserID) REFERENCES User_Details(UserID),
 CONSTRAINT STUDRESP_QuestionID_FK FOREIGN KEY (QuestionID) REFERENCES Questions_Details(QuestionID));

INSERT INTO Student_Responses VALUES(201,1,101,'A',1);
INSERT INTO Student_Responses VALUES(202,1,102,'A',1);
INSERT INTO Student_Responses VALUES(203,1,103,'B',0);
INSERT INTO Student_Responses VALUES(204,1,104,'B',1);
INSERT INTO Student_Responses VALUES(205,1,105,'C',1);
INSERT INTO Student_Responses VALUES(206,2,101,'A',1);
INSERT INTO Student_Responses VALUES(207,2,102,'A',1);
INSERT INTO Student_Responses VALUES(208,2,103,'C',0);
INSERT INTO Student_Responses VALUES(209,2,104,'A',0);
INSERT INTO Student_Responses VALUES(210,2,105,'D',0);
INSERT INTO Student_Responses VALUES(211,3,111,'C',1);
INSERT INTO Student_Responses VALUES(212,3,112,'A',1);
INSERT INTO Student_Responses VALUES(213,3,113,'B',1);
INSERT INTO Student_Responses VALUES(214,3,114,'A',0);
INSERT INTO Student_Responses VALUES(215,3,115,'D',1);

INSERT INTO Student_Responses VALUES(216,2,111,'D',0);
INSERT INTO Student_Responses VALUES(217,2,112,'C',1);
INSERT INTO Student_Responses VALUES(218,2,113,'A',1);
INSERT INTO Student_Responses VALUES(219,2,114,'B',1);
INSERT INTO Student_Responses VALUES(220,2,115,'A',0);



CREATE TABLE Report_Card(
 ReportID NUMBER(6) NOT NULL,
 UserID NUMBER(6) NOT NULL,
 ExamID NUMBER(6) NOT NULL,
 Marks NUMBER(3) NOT NULL,
 Status VARCHAR2(5) NOT NULL,
 Exam_Date DATE NOT NULL,
 CONSTRAINT REPORTCARD_ReportID_PK PRIMARY KEY (ReportID),
 CONSTRAINT REPORTCARD_UserID_FK FOREIGN KEY (UserID) REFERENCES User_Details(UserID),
 CONSTRAINT REPORTCARD_ExamID_FK FOREIGN KEY (ExamID) REFERENCES Exam_Details(ExamID));




INSERT INTO Report_Card VALUES(301,1,51,4,'PASS','21-JAN-19');
INSERT INTO Report_Card VALUES(302,2,52,2,'FAIL','21-JAN-19');
INSERT INTO Report_Card VALUES(303,3,57,4,'PASS','03-MAR-19');

INSERT INTO Report_Card VALUES(304,2,57,3,'PASS','11-MAR-19');
commit;