import { Component, OnInit } from '@angular/core';
import { DeleteQuestionsForExamDto } from '../DeleteQuestionsForExamDto';
import { OnlineexamService } from '../onlineexam.service';

@Component({
  selector: 'app-deletequestions',
  templateUrl: './deletequestions.component.html',
  styleUrls: ['./deletequestions.component.css']
})
export class DeletequestionsComponent implements OnInit {

  deleteQuestionsForExamDto : DeleteQuestionsForExamDto = new DeleteQuestionsForExamDto
  status : string;
  constructor(private service : OnlineexamService) { }

  ngOnInit(): void {
  }

  deleteQuestions(){
    this.service.deleteQuestionsForExam(this.deleteQuestionsForExamDto).subscribe( data=> {
      this.status = data;
    })
  }
}
