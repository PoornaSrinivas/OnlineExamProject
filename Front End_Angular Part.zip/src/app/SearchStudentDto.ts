export class SearchStudentDto {

	
	examSpecialization: string;
	state: string;
	city: string;
	levels: string;
    marks: number;

}