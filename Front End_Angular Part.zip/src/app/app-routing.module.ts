import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddquestionsComponent } from './addquestions/addquestions.component';
import { AdminwelcompageComponent } from './adminwelcompage/adminwelcompage.component';
import { AppComponent } from './app.component';
import { DeletequestionsComponent } from './deletequestions/deletequestions.component';
import { ExampageComponent } from './exampage/exampage.component';
import { LoginComponent } from './login/login.component';
import { OldreportcardComponent } from './oldreportcard/oldreportcard.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';
import { ReportcardComponent } from './reportcard/reportcard.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { SearchstudentsComponent } from './searchstudents/searchstudents.component';
import { SelectexampageComponent } from './selectexampage/selectexampage.component';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';

const routes: Routes = [
  {path: 'login', component:LoginComponent},
  {path: 'welcome', component:WelcomepageComponent},
  {path: 'reportcard', component:ReportcardComponent},
  {path: 'oldreports', component :OldreportcardComponent},
  {path: 'selectexam', component :SelectexampageComponent},
  {path: 'adminwelcome', component :AdminwelcompageComponent},
  {path: 'addquestions', component :AddquestionsComponent},
  {path: 'deletequestions', component :DeletequestionsComponent},
  {path: 'register', component :RegisterpageComponent},
  {path: 'exampage', component :ExampageComponent},
  {path: 'aboutus', component :AboutusComponent},
  {path: 'searchstudents', component :SearchstudentsComponent},
  {path: 'resetpassword', component :ResetpasswordComponent}

  
];




@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
