
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../Message';
import { OnlineexamService } from '../onlineexam.service';
import { ResetPasswordDto } from '../ResetPasswordDto';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {


  resetPasswordDto : ResetPasswordDto = new ResetPasswordDto();
  confirmPassword : string;
  constructor(private service : OnlineexamService,
              private router : Router    
    ) { }
  message : Message = new Message();
  ngOnInit(): void {
  }
  checkPassword(){
    if(this.confirmPassword == this.resetPasswordDto.newPassword){
     
      this.resetPassword();
    }
    else{
      alert("Password and Confirm Password not matching")
    }
  } 
  resetPassword(){
    this.service.resetPasswordService(this.resetPasswordDto).subscribe(data=>{
      this.message = data;
     
      console.log(this.message)
      if(this.message.status=="Y"){
        alert(this.message.msg)
        this.router.navigate(['/login']);
      }
      else{
        alert(this.message.msg)
      }

    })

  }
}
