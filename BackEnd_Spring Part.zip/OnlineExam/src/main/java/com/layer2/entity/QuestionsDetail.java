package com.layer2.entity;



import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the QUESTIONS_DETAILS database table.
 * 
 */
@Entity
@Table(name="QUESTIONS_DETAILS")
@NamedQuery(name="QuestionsDetail.findAll", query="SELECT q FROM QuestionsDetail q")
public class QuestionsDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int questionid;

	private String answer;

	private String optiona;

	private String optionb;

	private String optionc;

	private String optiond;

	private String question;

	@Override
	public String toString() {
		return "QuestionsDetail [questionid=" + questionid + ", answer=" + answer + ", optiona=" + optiona
				+ ", optionb=" + optionb + ", optionc=" + optionc + ", optiond=" + optiond + ", question=" + question
				+ "]";
	}
	
	
	//bi-directional many-to-one association to ExamDetail
	@ManyToOne
	@JoinColumn(name="EXAMID")
	private ExamDetail examDetail;

	//bi-directional many-to-one association to StudentRespons
	@OneToMany(mappedBy="questionsDetail",  cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
	private Set<StudentRespons> studentResponses;

	public QuestionsDetail() {
	}

	public int getQuestionid() {
		return this.questionid;
	}

	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getOptiona() {
		return this.optiona;
	}

	public void setOptiona(String optiona) {
		this.optiona = optiona;
	}

	public String getOptionb() {
		return this.optionb;
	}

	public void setOptionb(String optionb) {
		this.optionb = optionb;
	}

	public String getOptionc() {
		return this.optionc;
	}

	public void setOptionc(String optionc) {
		this.optionc = optionc;
	}

	public String getOptiond() {
		return this.optiond;
	}

	public void setOptiond(String optiond) {
		this.optiond = optiond;
	}

	public String getQuestion() {
		return this.question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public ExamDetail getExamDetail() {
		return this.examDetail;
	}

	public void setExamDetail(ExamDetail examDetail) {
		this.examDetail = examDetail;
	}

	public Set<StudentRespons> getStudentResponses() {
		return this.studentResponses;
	}

	public void setStudentResponses(Set<StudentRespons> studentResponses) {
		this.studentResponses = studentResponses;
	}

	public StudentRespons addStudentRespons(StudentRespons studentRespons) {
		getStudentResponses().add(studentRespons);
		studentRespons.setQuestionsDetail(this);

		return studentRespons;
	}

	public StudentRespons removeStudentRespons(StudentRespons studentRespons) {
		getStudentResponses().remove(studentRespons);
		studentRespons.setQuestionsDetail(null);

		return studentRespons;
	}

	

}