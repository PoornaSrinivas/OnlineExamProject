package com.service.test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dto.*;
import com.layer5.exception.*;
import com.layer6.service.*;

@SpringBootTest
public class ReportCardServiceTest {
	
	@Autowired
	ExamService eSer;
	
	@Autowired
	ReportCardService rcSer;
	
	@Autowired
	ExamDetailRepo edRepo;
	

	@Autowired
	ReportCardRepo rcRepo;
	
	@Test//To add questions to exam by useing addquestionstoexam()
	void contextLoads1() {
		
		SearchStudentDto ssDto = new SearchStudentDto();
		ssDto.setCity("KKD"); ssDto.setState("AP"); ssDto.setLevels("LEVEL1");  ssDto.setExamSpecialization("SQL");
		System.out.println("---------------------------------");
		System.out.println("Set the ssDto : "+ssDto);
		System.out.println("---------------------------------");
		
		Set<UserInfoDto> uiList = rcSer.searchStudentService(ssDto);
		for(UserInfoDto uiDto : uiList) {
			System.out.println("---------------------------------");
			System.out.println("Set the ssDto : "+uiDto);
			System.out.println("---------------------------------");
			
		}
		
		
	}
}