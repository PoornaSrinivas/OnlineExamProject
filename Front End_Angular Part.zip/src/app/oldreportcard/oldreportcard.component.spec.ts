import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldreportcardComponent } from './oldreportcard.component';

describe('OldreportcardComponent', () => {
  let component: OldreportcardComponent;
  let fixture: ComponentFixture<OldreportcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldreportcardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OldreportcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
