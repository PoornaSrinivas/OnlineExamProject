package com.layer3.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.layer2.entity.ExamDetail;
import com.layer2.entity.QuestionsDetail;

@Repository
public class ExamDetailRepoImpl implements ExamDetailRepo {
	
	@PersistenceContext
	EntityManager entityManager;

	
	//ExamDetails Started
	
	@Transactional
	public ExamDetail getOneExam(int ExamId) {
		ExamDetail examdetail = entityManager.find(ExamDetail.class, ExamId);
		return examdetail;
	}

	@Transactional
	public List<ExamDetail> getAllExams() {
		
			Query query = entityManager.createQuery(" from ExamDetail");
			List<ExamDetail>  examdetail = query.getResultList();
			return examdetail;
		
	}

	@Transactional
	public void addExam(ExamDetail ref) {
			System.out.println(entityManager);
			entityManager.persist(ref);
		
	}

	@Transactional
	public void removeExam(int ExamId) {
		ExamDetail examdetail = entityManager.find(ExamDetail.class, ExamId);
		entityManager.remove(examdetail);
		
	}
	
	
	@Transactional
	public ExamDetail getOneExam(String examspecialization, String examlevel) {
		Query query =  entityManager.createQuery("FROM ExamDetail  WHERE EXAM_SPECIALIZATION = '"+examspecialization+"' and EXAM_LEVEL = '"+examlevel+"'");
		
		System.out.println("query created");
		 List<ExamDetail> udList = query.getResultList();
		 
		ExamDetail ed = udList.get(0);
		
		System.out.println("--------------------------------------------");
		System.out.println("Got the exam");
		System.out.println("--------------------------------------------");
		return ed;

		
	}


}
