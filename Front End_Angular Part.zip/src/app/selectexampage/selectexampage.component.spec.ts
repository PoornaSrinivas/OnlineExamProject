import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectexampageComponent } from './selectexampage.component';

describe('SelectexampageComponent', () => {
  let component: SelectexampageComponent;
  let fixture: ComponentFixture<SelectexampageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectexampageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectexampageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
