package com.layer4.dtoold;

public class SelectExamDTO {
	
	private int examid;
	private String examSpecialization;
	private String examLevel;
	private String time;


public int getExamid() {
	return this.examid;
}

public void setExamid(int examid) {
	this.examid = examid;
}

public String getExamSpecialization() {
	return this.examSpecialization;
}

public void setExamSpecialization(String examSpecialization) {
	this.examSpecialization = examSpecialization;
}

public String getExamLevel() {
	return this.examLevel;
}

public void setExamLevel(String examLevel) {
	this.examLevel = examLevel;
}

public String getTime() {
	return this.time;
}

public void setTime(String time) {
	this.time = time;
}
}