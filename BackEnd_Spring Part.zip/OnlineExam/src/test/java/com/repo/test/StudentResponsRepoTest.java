package com.repo.test;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dtoold.*;

@SpringBootTest
public class StudentResponsRepoTest {

	@Autowired
	StudentResponsRepo srRepo;
	
	@Autowired
	UserDetailRepo udRepo;
	

	@Autowired
	QuestionsDetailRepo qdRepo;
	
	@Autowired
	ExamDetailRepo edRepo;

	//to get a single student response using userid
	@Test
	void contextLoads1() { 
		
		List<StudentRespons> quesList = new ArrayList<StudentRespons>();
		//Set<QuestionsDetail> quesList = new HashSet<QuestionsDetail>();
		quesList = srRepo.getResponses(4);
		System.err.println("Student Responses");
		for (StudentRespons studentRespons : quesList) {
			System.out.println("studenrespones : "+studentRespons);
		}
			
	}
	
	//to get all the responses 
	@Test
	void contextLoads2() {		
		List<StudentRespons> std;
		std = srRepo.getallresponses();
		System.out.println("student responses");
		for (StudentRespons studentRespons : std) {
			System.out.println("student responses : "+studentRespons);
		}
		}
	
	
	//to add the new student responses depend upon user id
	@Test
	void contextLoads3() {		
		
		UserDetail urf = udRepo.getOneUser(3); //it is select a userid from userdetails
		QuestionsDetail qdr = qdRepo.getOneQuestion(116);
		
		StudentRespons sr = new StudentRespons();
		
		sr.setQuestionStatus(0);
		sr.setResponse("B");
		sr.setUserDetail(urf);
		sr.setQuestionsDetail(qdr);
		
		System.out.println("Add Student Responses() is called...");
		System.out.println("Student Responses added: " +sr);
		
		srRepo.addstudentresponses(sr);
		
		
	}

	//to remove a student response using response id
	@Test	
	void contextLoads4() {
		srRepo.removeStudentresponse(43);
		srRepo.removeStudentresponse(44);
		srRepo.removeStudentresponse(45);
		srRepo.removeStudentresponse(46);
		
		
	}
	
	
	//to get responses of userid for particular exam examid	
	@Test
	void contextLoads5() {
	ExamDetail exam = edRepo.getOneExam(51);
	List<QuestionsDetail> qList = qdRepo.getQuestions(51);
	List<StudentRespons> respList = srRepo.getResponses(3);
	
	for(StudentRespons sr : respList) {
	   int srqid = sr.getQuestionsDetail().getQuestionid();
		for(QuestionsDetail qd : qList){
	        if(srqid == qd.getQuestionid()) {
	        	System.out.println("---------------------------------------------------------------------");
	        	System.out.println("Response : "+sr);
	        	System.out.println("Exam id :"+exam.getExamid()+"===> Questionid of response : "+srqid+"==> QuestionId of question :"+qd.getQuestionid() );
	        	System.out.println("---------------------------------------------------------------------");
	        	break;
	                
	        }            
	    }
	}

	}
	
	//to add the new student responses depend upon user id for partiular exam
	@Test
	void contextLoads6() {		
		
		UserDetail urf = udRepo.getOneUser(3); //it is select a userid from userdetails
		//these question are for examid=53
		QuestionsDetail q1 = qdRepo.getOneQuestion(40);
		QuestionsDetail q2 = qdRepo.getOneQuestion(41);
		QuestionsDetail q3 = qdRepo.getOneQuestion(42);
		//QuestionsDetail q4 = qRepo.getOneQuestion(104);
		//QuestionsDetail q5 = qRepo.getOneQuestion(105);
				 						
		StudentRespons sr1 = new StudentRespons();StudentRespons sr2 = new StudentRespons();StudentRespons sr3 = new StudentRespons();
		StudentRespons sr4 = new StudentRespons();StudentRespons sr5 = new StudentRespons();
				
		sr1.setResponse("A"); sr1.setUserDetail(urf); sr1.setQuestionsDetail(q1); sr1.setQuestionStatus(1);
		sr2.setResponse("A"); sr2.setUserDetail(urf); sr2.setQuestionsDetail(q2); sr2.setQuestionStatus(0);
		sr3.setResponse("C"); sr3.setUserDetail(urf); sr3.setQuestionsDetail(q3); sr3.setQuestionStatus(1);
		//sr4.setResponse("D"); sr4.setUserDetail(urf); sr4.setQuestionsDetail(q4); sr4.setQuestionStatus(0);
		//sr5.setResponse("C"); sr5.setUserDetail(urf); sr5.setQuestionsDetail(q5); sr5.setQuestionStatus(1);
				
				
		srRepo.addstudentresponses(sr1);srRepo.addstudentresponses(sr2);srRepo.addstudentresponses(sr3);srRepo.addstudentresponses(sr4);srRepo.addstudentresponses(sr5);
		System.out.println("---------------------------------------------------------------");
		System.out.println("Responses are added.");
		System.out.println("---------------------------------------------------------------");
				
				
		}
	
	//to add the new student responses depend upon user id for partiular exam
		@Test
		void contextLoads7() {		
			
			UserDetail urf = udRepo.getOneUser(1); //it is select a userid from userdetails
			//these question are for examid=53
			int examId = 53;
			ExamDetail examRef = edRepo.getOneExam(examId);
			Set<QuestionsDetail> qdList = examRef.getQuestionsDetails();
			
			System.out.println("----------------------------------------------------------------------------------------------------");
			System.out.println("qdList is created");
			System.out.println("-----------------------------------------------------------------------------------------------");
			
			
			
			List<ResponseDto> rDtoList = new ArrayList<ResponseDto>();
			ResponseDto rDto1 = new ResponseDto();
			ResponseDto rDto2 = new ResponseDto();
			ResponseDto rDto3 = new ResponseDto();
			
			
			rDto1.setExamId(53); rDto1.setQuestionId(52); rDto1.setUserId(1); rDto1.setResponse("B");
			rDto2.setExamId(53); rDto2.setQuestionId(53); rDto2.setUserId(1); rDto2.setResponse("C");
			rDto3.setExamId(53); rDto3.setQuestionId(54); rDto3.setUserId(1); rDto3.setResponse("D");
			
			rDtoList.add(rDto1); rDtoList.add(rDto2); rDtoList.add(rDto3); 
			
			System.out.println("----------------------------------------------------------------------------------------------------");
			System.out.println("rDtoList is created");
			System.out.println("-----------------------------------------------------------------------------------------------");

			StudentRespons sr = new StudentRespons();
			for(QuestionsDetail qd : qdList) {
				for(ResponseDto rDto  : rDtoList) {
					
					if(qd.getQuestionid() == rDto.getQuestionId()) {
						
						sr.setResponse(rDto.getResponse());
						sr.setQuestionsDetail(qd);
						sr.setUserDetail(urf);
						int qSat = 0;
						String answer = qd.getAnswer();
						if(answer.equalsIgnoreCase(rDto.getResponse())) {
							qSat = 1;
						}
						sr.setQuestionStatus(qSat);
						srRepo.addstudentresponses(sr);
						System.out.println("----------------------------------------------------------------------------------------------------");
						System.out.println("Response added for  UserId=====> "+urf.getUserid()+" QuestionId====> "+ qd.getQuestionid()+" for rDto.respons(question)==> "+rDto.getQuestionId());
						System.out.println("-----------------------------------------------------------------------------------------------");
					}
					
				}
			}
			
	}
		
	@Test
	void contextLoads10() { 
			
		List<StudentRespons> quesList = new ArrayList<StudentRespons>();
		//Set<QuestionsDetail> quesList = new HashSet<QuestionsDetail>();
		StudentRespons studentRespons = srRepo.getsingleresponse(4, 101);
		System.out.println("---------------------------------------------------------------");
		System.out.println("studenrespones : "+studentRespons);
		System.out.println("---------------------------------------------------------------");	
	}		
}
