
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OnlineexamService } from '../onlineexam.service';
import { UserRegisterDto } from '../UserRegisterDto';
import { Message } from '../Message';

@Component({
  selector: 'app-registerpage',
  templateUrl: './registerpage.component.html',
  styleUrls: ['./registerpage.component.css']
})
export class RegisterpageComponent implements OnInit {

  conPass : string;

  dateOfBirth = new Date;

  year = this.dateOfBirth.getFullYear;
  month = this.dateOfBirth.getMonth;
  date = this.dateOfBirth.getDate;

  
  //dateString =(this.year.toString())+'-'+(this.month.toString())+'-'+(this.date.toString()); 


  regForm : UserRegisterDto = new UserRegisterDto();

  states = ["","ANDHRA PRADESH","TELANGANA","TAMIL NADU","MAHARASHTRA","KARNATAKA","GUJARAT","UTTAR PRADESH","PUNJAB","BIHAR","KERALA"]

  cities = ["","VIZAG","HYDERABAD","CHENNAI","MUMBAI","BANGALORE","BARODA", "LUCKNOW","CHANDIGARH","PATNA","TRIVANDRUM"]

  message : Message = new Message();
  constructor(private service: OnlineexamService,
			  private router : Router
	) { }

  ngOnInit(): void {
  }

  submitForm(){
    if(this.validateForm()){
      this.service.registerUserService(this.regForm).subscribe(data=>{
		this.message=data;
		if(this.message.status=="Y"){
			alert(this.message.msg)
			this.router.navigate(['/login']);
		  }
		  else{
			alert(this.message.msg)
		  }
	  })
    }
    else{
      alert("Invalid details")
    }
  }

  validateForm(){

		//this.regForm.dateOfBirth = this.dateString
		console.log("regForm DOB"+this.regForm.dateOfBirth)
		//console.log("Dob :"+this.dateOfBirth)
  	
		if(this.regForm.fullName==null || this.regForm.fullName=="")
		{
			alert("First Name Cannot be blank");
			return false;
		}
		
		
		if(this.regForm.email==null || this.regForm.email=="")
		{
			alert("Email Cannot be blank");
			return false;
		}
		
		if(this.regForm.password==null || this.regForm.password=="")
		{
			alert("Password cannot be blank");
			return false;
		}
		
		if(this.conPass==null || this.conPass=="")
		{
			alert("Confirmed Password cannot be balnk");
			return false;
		}
		if( this.regForm.password!= this.conPass)
		{
			alert("Confirmed Password does NOT match with password entered");
			return false;
		}
				
		if(this.regForm.state=="")
		{
			alert("Please select the state");
			return false;
		}
		if(this.regForm.city=="")
		{
			alert("Please select the city");
			return false;
    }
    if(this.regForm.dateOfBirth==" " || this.regForm.dateOfBirth==null)
		{
			alert("Please select the Date of birth");
			return false;
    }
	
		return true;
		
	
  }

  
}


