package com.layer3.repo;
import com.layer2.entity.*;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
@Repository
public interface QuestionsDetailRepo {
	

	
	  public List<QuestionsDetail> getQuestions(int examId);//imp1
	  public QuestionsDetail getOneQuestion(int qId);//imp2
	  public void addQuestion(QuestionsDetail question);  //imp3
	  public void deleteQuestionByHql(int questionId); //imp4
	  public void deleteQuestion(int questionId);
	  public void updateQuestion(QuestionsDetail question);//imp5
	  public void deleteQuestionsByExam(int examId);//imp6

}
