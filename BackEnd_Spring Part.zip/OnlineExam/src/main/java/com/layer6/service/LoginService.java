package com.layer6.service;


import com.layer4.dto.*;
import com.layer5.exception.OnlineExamException;


public interface LoginService {
	
	public UserInfoDto userLoginService(UserLoginDto ulDto) throws OnlineExamException;
	public AdminLoginDto adminLoginService(AdminLoginDto alDto) throws OnlineExamException;
	public String resetPasswordService(ResetPasswordDto rpDto) throws OnlineExamException;
	public String userRegisterService(UserRegisterDto rgDto ) throws  OnlineExamException;
	


}
