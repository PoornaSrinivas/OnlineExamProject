package com.layer3.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.layer2.entity.ExamDetail;
import com.layer2.entity.QuestionsDetail;
import com.layer2.entity.StudentRespons;
import com.layer2.entity.UserDetail;

@Repository
public class UserDetailRepoImpl  implements UserDetailRepo {

	
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public UserDetail getOneUser(int userId) {
		UserDetail userdetail = entityManager.find(UserDetail.class, userId);
		return userdetail;
	}
	
	@Transactional
	public List<UserDetail> getAllUsers() {
		String s = "From UserDetail";
		Query query = entityManager.createQuery(s);
		List<UserDetail> userdetail = query.getResultList();
		return userdetail;
	}

	@Transactional
	public void addUser(UserDetail ref) {
		System.out.println(entityManager);
		entityManager.merge(ref);
		
	}

	@Transactional
	public void updateUserEmail(int userId, String newEmail) {
		UserDetail userdetail = entityManager.find(UserDetail.class, userId);
		userdetail.setEmail(newEmail);
		entityManager.merge(userdetail);
		
	}

	@Transactional
	public void updateUserPassword(int userId, String newPass) {
		UserDetail userdetail = entityManager.find(UserDetail.class, userId);
		userdetail.setPassword(newPass);
		entityManager.merge(userdetail);
		
	}

	@Transactional
	public void updateUserMobilNumber(int userId, String newMobileNumber) {
		UserDetail userdetail = entityManager.find(UserDetail.class, userId);
		userdetail.setMobile(newMobileNumber);
		entityManager.merge(userdetail);
		
	}

	@Transactional
	public void removeUser(int userId) {
		UserDetail userdetail = entityManager.find(UserDetail.class, userId);
		entityManager.remove(userdetail);
		
	}

	@Transactional
	public List<UserDetail> getuser(int userid) {
		
		 Query query =  entityManager.createQuery("FROM UserDetail  WHERE userid="+userid);
		 List<UserDetail> singleuserdetail = query.getResultList();
		 
		return singleuserdetail;
	}

	@Transactional
	public List<UserDetail> getuserswithstateandcity(String state, String city) {
		
		
		Query query =  entityManager.createQuery("FROM UserDetail  WHERE state= "+state+" and city = "+city);
		 List<UserDetail> singleuserdetail = query.getResultList();
		 
		return singleuserdetail;
	}

	@Transactional
	public UserDetail getOneUser(String email) {
		System.out.println("--------------------------------------------");
		System.out.println("getOneUSer(email) is called");
		System.out.println("--------------------------------------------");
		
		Query query =  entityManager.createQuery(" FROM UserDetail  WHERE email= "+"'"+email+"'");
		System.out.println("query created");
		 List<UserDetail> udList = query.getResultList();
		 UserDetail ud = udList.get(0);
		
		System.out.println("--------------------------------------------");
		System.out.println("Got the user");
		System.out.println("--------------------------------------------");
		return ud;
	}

	
	

	
	
}