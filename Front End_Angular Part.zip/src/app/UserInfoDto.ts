import { UserRegisterDto } from "./UserRegisterDto";

export class UserInfoDto extends UserRegisterDto{
    userId : number;
    status : String;

}