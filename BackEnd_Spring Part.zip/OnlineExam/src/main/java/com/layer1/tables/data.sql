
DROP TABLE Admin_Login cascade constraints;
DROP TABLE Student_Responses cascade constraints;
DROP TABLE Report_Card cascade constraints;
DROP TABLE Questions_Details cascade constraints;
DROP TABLE Exam_Details cascade constraints;
DROP TABLE User_Details cascade constraints;


INSERT INTO User_Details(UserID,Email,Password,FullName,Mobile,Date_of_Birth,City, State, Qualification, Year_of_completion) VALUES (1,'Srinivas@gmail.com','Srinu@124','Srinivas','9567898979','01-FEB-1996','VSKP','AP','B.TECH',2018);
INSERT INTO User_Details(UserID,Email,Password,FullName,Mobile,Date_of_Birth,City, State, Qualification, Year_of_completion) VALUES (2,'Anil@gmail.com','Anil@2729','Anil','9345898457','11-Jan-1996','KKD','AP','B.TECH',2018);
INSERT INTO User_Details(UserID,Email,Password,FullName,Mobile,Date_of_Birth,City, State, Qualification, Year_of_completion) VALUES (3,'Kaveri@gmail.com','Kaveri@235','Kaveri','9547898678','22-APR-1996','PTN','BIH','B.TECH',2018);
INSERT INTO User_Details(UserID,Email,Password,FullName,Mobile,Date_of_Birth,City, State, Qualification, Year_of_completion) VALUES (4,'Ravi@gmail.com','Ravi@1456','Ravi','8667898567','18-JUN-1994','VZM','AP','M.TECH',2018);

					



INSERT INTO Admin_Login(Email, Password) values('kalyan@gmail.com','kalyan');
INSERT INTO Admin_Login(Email, Password) values('manju@gmail.com','manju');




INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('51','JAVA','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('52','JAVA','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('53','JAVA','LEVEL3',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('54','PYTHON','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('55','PYTHON','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('56','PYTHON','LEVEL3',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('57','SQL','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('58','SQL','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('59','SQL','LEVEL3',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('60','C/C++','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('61','C/C++','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('62','C/C++','LEVEL3',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('63','PHP','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('64','PHP','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('65','PHP','LEVEL3',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('66','C#/.NET','LEVEL1',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('67','C#/.NET','LEVEL2',10,5,'60 min');
INSERT INTO Exam_Details(ExamID, Exam_Specialization, Exam_level, Number_Of_Questions,Passing_Mark, Time) values('68','C#/.NET','LEVEL3',10,5,'60 min');




+INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(101,'Java-level-1-Question-1','A','B','C','D','A',51);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(102,'Java-level-1-Question-2','A','B','C','D','A',51);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(103,'Java-level-1-Question-3','A','B','C','D','C',51);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(104,'Java-level-1-Question-4','A','B','C','D','B',51);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(105,'Java-level-1-Question-5','A','B','C','D','C',51);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(106,'Java-level-2-Question-1','A','B','C','D','D',52);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(107,'Java-level-2-Question-2','A','B','C','D','A',52);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(108,'Java-level-2-Question-3','A','B','C','D','B',52);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(109,'Java-level-2-Question-4','A','B','C','D','D',52);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(110,'Java-level-2-Question-5','A','B','C','D','A',52);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(111,'SQL-level-1-Question-1','A','B','C','D','C',57);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(112,'SQL-level-1-Question-2','A','B','C','D','A',57);
INSERT INTO Questions_Details(QuestionID ,Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(113,'SQL-level-1-Question-3','A','B','C','D','B',57);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(114,'SQL-level-1-Question-4','A','B','C','D','B',57);
INSERT INTO Questions_Details(QuestionID, Question,OptionA,OptionB,OptionC,OptionD,Answer,ExamID) VALUES(115,'SQL-level-1-Question-5','A','B','C','D','D',57);






INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(201,1,101,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(202,1,102,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(203,1,103,'B',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(204,1,104,'B',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(205,1,105,'C',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(206,2,101,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(207,2,102,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(208,2,103,'C',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(209,2,104,'A',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(210,2,105,'D',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(211,3,111,'C',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(212,3,112,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(213,3,113,'B',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(214,3,114,'A',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(215,3,115,'D',1);

INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(216,2,111,'D',0);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(217,2,112,'C',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(218,2,113,'A',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(219,2,114,'B',1);
INSERT INTO Student_Responses(ResponseID, UserID, QuestionID, Response, Question_Status) VALUES(220,2,115,'A',0);





INSERT INTO Report_Card(ReportID, UserID, ExamID, Marks, Status, Exam_Date) VALUES(301,1,51,4,'PASS','21-JAN-19');
INSERT INTO Report_Card(ReportID, UserID, ExamID, Marks, Status, Exam_Date) VALUES(302,2,52,2,'FAIL','21-JAN-19');
INSERT INTO Report_Card(ReportID, UserID, ExamID, Marks, Status, Exam_Date) VALUES(303,3,57,4,'PASS','03-MAR-19');

INSERT INTO Report_Card(ReportID, UserID, ExamID, Marks, Status, Exam_Date) VALUES(304,2,57,3,'PASS','11-MAR-19');


commit;