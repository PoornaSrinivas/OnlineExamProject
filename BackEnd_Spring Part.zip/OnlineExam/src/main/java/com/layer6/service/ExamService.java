package com.layer6.service;

import java.util.Set;

import com.layer4.dto.*;
import com.layer5.exception.OnlineExamException;


public interface ExamService{
	
	public String addQuestionsForExamService(AddQuestionsForExamDto aqeDto)  throws OnlineExamException ;
	public Set<QuestionDetailsDto> getAllquestionsForExamService(ExamInformationDto examInfoDto);
	public Set<ExamInformationDto> selectExamsService();
	public String deleteQuestionsForExamService(DeleteQuestionsForExamDto dqeDto) throws OnlineExamException;
	public ReportCardDto addResponsesService(AddResponsesForExamDto areDto);

}
