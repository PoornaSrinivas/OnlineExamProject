export class UserRegisterDto {
	
	fullName : string;
	email : string;
	password : string;
    mobile : string;
	city : string;
	dateOfBirth : string;
	state : string;
	qualification : string;
    yearOfCompletion : number;

}