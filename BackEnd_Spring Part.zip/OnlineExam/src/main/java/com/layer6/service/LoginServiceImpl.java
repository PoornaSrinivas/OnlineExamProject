package com.layer6.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.swing.text.DateFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.layer2.entity.*;

import com.layer3.repo.*;
import com.layer4.dto.*;
import com.layer5.exception.OnlineExamException;

@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	UserDetailRepo udRepo;
	
	@Autowired
	AdminLoginRepo alRepo;
	

	
	@Override
	public UserInfoDto userLoginService(UserLoginDto ulDto) throws OnlineExamException{
		
		
			UserInfoDto userInfoDto = new UserInfoDto();
			try {
				String email = ulDto.getUserEmail();
				String password = ulDto.getPassword();
				
				UserDetail udRef;
				try {
					udRef = udRepo.getOneUser(email);
					userInfoDto.setStatus("Y");
				} catch (Exception e) {
					throw new OnlineExamException("Invalid Credentials");
				} 
				System.out.println("====================================");
				System.out.println("got the udRef :"+udRef.getPassword()+"  userid "+udRef.getUserid());
				System.out.println("====================================");
				
				System.out.println("====================================");
				System.out.println("ulDto :"+ulDto.getPassword());
				System.out.println("====================================");
				
				
				if(password.equals(udRef.getPassword())) {
					userInfoDto.setUserId(udRef.getUserid());
					userInfoDto.setEmail(udRef.getEmail());
					System.out.println("PasswordMatched");
				}else {
					userInfoDto.setStatus("N");
				}
			} catch (OnlineExamException e) {
				userInfoDto.setStatus("N");
			}
			
		return userInfoDto;		
	}


	@Override
	public AdminLoginDto adminLoginService(AdminLoginDto alDto) throws OnlineExamException {
		
		AdminLoginDto adminLoginDto = new AdminLoginDto();
		try {
			String email = alDto.getAdminEmail();
			String password = alDto.getPassword(); 
			
			AdminLogin alRef;
			
				try {
					alRef = alRepo.getAdmin(email);
					adminLoginDto.setStatus("Y");
				} catch (Exception e) {
					throw new OnlineExamException("Invalid details");
				}
			
				
			if(password.equals(alRef.getPassword())) {
				adminLoginDto.setAdminEmail(alRef.getEmail());
				System.out.println("PasswordMatched");
			}else {
				adminLoginDto.setStatus("N");
			}
		} catch (OnlineExamException e) {
			adminLoginDto.setStatus("N");
		}
		
	return adminLoginDto;	
	}


	@Override
	public String resetPasswordService(ResetPasswordDto rpDto) throws OnlineExamException{ //In rpDto in  email and newpassword
		
		try {
		
				UserDetail uRef = udRepo.getOneUser(rpDto.getEmail());//based pm email we get one user(in user we have uerid)
				//for update password we need userid and password
				udRepo.updateUserPassword(uRef.getUserid(), rpDto.getNewPassword());
			
				return "Password changed successfully";
	
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new OnlineExamException("Invalid email-Id");
		}

	}
	
	@Override
	public String userRegisterService(UserRegisterDto rgDto) throws OnlineExamException {

		List<UserDetail> user = udRepo.getAllUsers();
		
		try {
	
			UserDetail userdetail = new UserDetail();
						
			userdetail.setEmail(rgDto.getEmail());
			userdetail.setFullname(rgDto.getFullName());
			userdetail.setPassword(rgDto.getPassword());
	        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(rgDto.getDateOfBirth());
	        java.sql.Date sqlDate = new java.sql.Date(date.getTime());	
	       
			userdetail.setDateOfBirth(sqlDate);
			
			userdetail.setCity(rgDto.getCity());
			userdetail.setMobile(rgDto.getMobile());
			userdetail.setQualification(rgDto.getQualification());
			userdetail.setYearOfCompletion(rgDto.getYearOfCompletion());
			userdetail.setState(rgDto.getState());
		
			udRepo.addUser(userdetail);
			
			System.out.println("------------------------------------------");
			System.out.println("User Registered");
			System.out.println("------------------------------------------");
			return "User registered";
		
		} catch (Exception e) {
	
			throw new OnlineExamException("Unable to register");
		}
	
	
		


	}
	
}
	