package com.layer6.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dto.*;




@Service
public class ReportCardServiceImpl implements ReportCardService {
	
	
	@Autowired
	ReportCardRepo rcRepo;
	
	@Autowired
	ExamDetailRepo edRepo;
	
	@Autowired
	UserDetailRepo udRepo;
	
	@Autowired
	StudentResponsRepo srRepo;
	
	
	@Override
	public Set<ReportCardDto> getReportCardService(int userId) {

	
		List<ReportCard> reportCardList = rcRepo.getReportCards(userId);
		Set<ReportCardDto> reportCardDtoList = new HashSet<ReportCardDto>();
		
		for(ReportCard reportCard: reportCardList) {
			ReportCardDto reportCardDto = new ReportCardDto();
			reportCardDto.setExamLevel(reportCard.getExamDetail().getExamLevel());
			reportCardDto.setExamSpec(reportCard.getExamDetail().getExamSpecialization());
			reportCardDto.setFullName(reportCard.getUserDetail().getFullname());
			reportCardDto.setMarks(reportCard.getMarks());
			reportCardDto.setStatus(reportCard.getStatus());
			
			reportCardDtoList.add(reportCardDto);
		}
		 
		return reportCardDtoList;
	}

	@Override
	public Set<UserInfoDto> searchStudentService(SearchStudentDto ssDto) {
		
		
		ExamDetail examFromDto = edRepo.getOneExam(ssDto.getExamSpecialization(), ssDto.getLevels());
		int cutOffMarksFromDto = ssDto.getMarks();
		List<ReportCard> reportCardList = rcRepo.getAllReportCards();
		Set<UserInfoDto> uiDtoList = new HashSet<UserInfoDto>();
		System.out.println("---------------------------------");
		System.out.println("Got ReportCards : ");
		System.out.println("---------------------------------");
		
		for(ReportCard rc : reportCardList) {
			
			int rcExamId = rc.getExamDetail().getExamid();
			String rcState = rc.getUserDetail().getState();
			String rcCity = rc.getUserDetail().getCity();
			System.out.println("---------------------------------");
			System.out.println("Got state and city : ");
			System.out.println("---------------------------------");
			if((rcExamId == examFromDto.getExamid()) && (rc.getMarks() >= cutOffMarksFromDto)) {
				System.out.println("---------------------------------");
				System.out.println("first if");
				System.out.println("---------------------------------");
				
				if((rcState.equalsIgnoreCase(ssDto.getState())) && (rcCity.equalsIgnoreCase(ssDto.getCity()))) {
					System.out.println("---------------------------------");
					System.out.println("Second if condition : ");
					System.out.println("---------------------------------");
					
					UserDetail rcUser = rc.getUserDetail();
					UserInfoDto uiDto = new UserInfoDto();
					uiDto.setFullName(rcUser.getFullname());
					uiDto.setEmail(rcUser.getEmail());
					uiDto.setMobile(rcUser.getMobile());
					uiDto.setCity(rcUser.getCity());
					uiDto.setState(rcUser.getState());
					uiDtoList.add(uiDto);
				}
				

			}
		}
		return uiDtoList;
		
	}

	@Override
	public String generateReportCard(int examid, int userid) {
		
				//fetching exam and user details
				ExamDetail exam = edRepo.getOneExam(examid);
				UserDetail user = udRepo.getOneUser(userid);
				System.out.println("----------------------------------------------------------");
				System.out.println("user : "+user);
				System.out.println("----------------------------------------------------------");
				
				Set<QuestionsDetail> qList = exam.getQuestionsDetails();
				List<StudentRespons> srList = new ArrayList<StudentRespons>();
				List<StudentRespons> allsrList = srRepo.getResponses(userid);
				System.out.println("----------------------------------------------------------");
				System.out.println("response list length : "+allsrList.size());
				System.out.println("----------------------------------------------------------");
				
				for(StudentRespons rs : allsrList) {
					for(QuestionsDetail qd : qList) {
						int qId = qd.getQuestionid();
						if(qId == rs.getQuestionsDetail().getQuestionid()) {
							srList.add(rs);
						}
					}
					
				}
				
				//calculating the marks obtained by the user for the exam he submitted using the responses he has given.
				int marks = 0;
				String status = null;
				for(StudentRespons sr : srList) {
					marks = marks+sr.getQuestionStatus();
					System.out.println("------------------------------------------------------");
					System.out.println("Userid: "+sr.getUserDetail().getUserid());
					System.out.println("questionid : "+sr.getQuestionsDetail().getQuestionid());
					System.out.println("status : " +sr.getQuestionStatus());
					System.out.println("Marks : "+marks);
					System.out.println("------------------------------------------------------");
				}
				
				System.out.println("Marks : "+marks);
				//Checking weather user cleared the exam or not
				if(marks < exam.getPassingMark()) {
					status = "FAIL";
				}
				else {
					status="PASS";
				}
				
				//creating a new reportcard and inserting required values. and adding it to database
				ReportCard newRC = new ReportCard();
				newRC.setExamDetail(exam);
				newRC.setMarks(marks);
				newRC.setStatus(status);
				newRC.setUserDetail(user);
				
				rcRepo.addReportCard(newRC);
				System.out.println("----------------------------------------------------");
				System.out.println("ReportCard added : "+newRC);
				System.out.println("----------------------------------------------------");
				return "report card generated";
	}



}
