package com.service.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.layer2.entity.*;
import com.layer3.repo.*;
import com.layer4.dto.*;
import com.layer5.exception.*;
import com.layer6.service.*;

	

@SpringBootTest
public class LoginServiceTest {

	@Autowired
	LoginService lser;
	
	@Autowired
	UserDetailRepo udRepo;
	
	@Autowired
	ExamService eSer;
	
	/*
	 * @Test void contextLoads1() { UserLoginDto ulDto = new UserLoginDto(); try {
	 * 
	 * ulDto.setUserEmail("Srinivas@gmail.com"); ulDto.setPassword("Srinu@124");
	 * lser.userLogin(ulDto); String status = "User Logged In successfully";
	 * System.out.println("------------------------------");
	 * System.out.println("Status is :" +status);
	 * System.out.println("------------------------------"); } catch
	 * (OnlineExamException e) {
	 * 
	 * String status = e.getMessage();
	 * System.out.println("------------------------------");
	 * System.out.println("Status is :" +status);
	 * System.out.println("------------------------------"); }
	 * 
	 * }
	 */
	
	@Test
	void contextLoads1() {
		UserLoginDto ulDto = new UserLoginDto();
		
			
			ulDto.setUserEmail("Srinivas@gmail.com"); 
			ulDto.setPassword("Srinu@124");
			UserInfoDto userInfoDto = new UserInfoDto();
			try {
				userInfoDto = lser.userLoginService(ulDto);
			} catch (OnlineExamException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String status = "User Logged In successfully";
			System.out.println("------------------------------");
			System.out.println("output is :" +userInfoDto);
			System.out.println("------------------------------");
		
			
			
		
		
	}
	
	@Test
	void contextLoads2() throws OnlineExamException {
		try {
			ResetPasswordDto rpDto = new ResetPasswordDto();
			rpDto.setEmail("Sriniva@gmail.com");
			rpDto.setNewPassword("helloworld@124");
			lser.resetPasswordService(rpDto);
			String status = "Password changed sucessfully";
			System.out.println("------------------------------");
			System.out.println("Status is :" +status);
			System.out.println("------------------------------");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new OnlineExamException("User doesn't exist");
		}
		
	}
	
	@Test
	void contextLoads3() throws OnlineExamException {
		
		UserDetail userdetail = new UserDetail();
		
		UserRegisterDto rgDto = new UserRegisterDto();
		
		rgDto.setFullName("2134");
		rgDto.setEmail("rajesh@gmail.com");
		rgDto.setMobile("9865328956");
		rgDto.setCity("BNG");
		rgDto.setDateOfBirth("1992-12-18");
		rgDto.setState("KNT");
		rgDto.setQualification("M.Tech");
		rgDto.setYearOfCompletion(2018);
		userdetail.setEmail(rgDto.getEmail());
		userdetail.setFullname(rgDto.getFullName());
		
		 Date date=null;
		 java.sql.Date sqlDate = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(rgDto.getDateOfBirth());
			 sqlDate = new java.sql.Date(date.getTime());	
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	  		
		userdetail.setDateOfBirth(sqlDate);
		userdetail.setCity(rgDto.getCity());
		userdetail.setMobile(rgDto.getMobile());
		userdetail.setQualification(rgDto.getQualification());
		userdetail.setYearOfCompletion(rgDto.getYearOfCompletion());
		userdetail.setState(rgDto.getState());
	
	
		lser.userRegisterService(rgDto);
		
		System.out.println("------------------------------------------");
		System.out.println("User Registered");
		System.out.println("------------------------------------------");
		//return "User registered";
	}
}
